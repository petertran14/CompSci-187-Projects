package search;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/**
 * An implementation of a Searcher that performs an iterative search,
 * storing the list of next states in a Queue. This results in a
 * breadth-first search.
 * 
 */
public class QueueBasedBreadthFirstSearcher<T> extends Searcher<T> {
	
	private  Map<T, T> predecessor;

	public QueueBasedBreadthFirstSearcher(SearchProblem<T> searchProblem) {
		super(searchProblem);
	}

	@Override
	public List<T> findSolution() {
		// Frontier for expansion.
		Queue<T> frontier = new LinkedList<>();
		
		// Adding the initial state, for this problem is the Integer 0.
		frontier.add(searchProblem.getInitialState());
		
		// This map will help us backtrack the path to the solution.
		predecessor = new HashMap<>();
		predecessor.put(searchProblem.getInitialState(), null);
		
		// This list will store all the integers that be back-pedaled.
		List<T> path = new ArrayList<>();
		
		// While there are still frontiers to expand to.
		while(!frontier.isEmpty()) {
			
			// Get the head node.
			T current = frontier.remove();
			
			// Expand the node, find its neighbors and loop through them.
			for (T next : searchProblem.getSuccessors(current)) {
				
				// If the neighbors are new to our map.
				if (!predecessor.containsKey(next)) {
					
					// Add to map and queue.
					predecessor.put(next, current);
					frontier.add(next);
				}
			}
			
			// We have found a goal
			if (searchProblem.isGoal(current)) {
				
				// Pushfront that node to our path.
				path.add(current);
				
				// The previous node is the item that is mapped to the key.
				T previous = predecessor.get(current);
				
				// Back-pedal to the start node.
				while (previous != null) {
					
					// Push-front the nodes to the path.
					path.add(0, previous);
					
					// Backward traversing.
					previous = predecessor.get(previous);
				}
				
				// Prevents an infinite loop when nodes have infinite branches.
				break;
			}
		}
		
		return path;
	}
}
