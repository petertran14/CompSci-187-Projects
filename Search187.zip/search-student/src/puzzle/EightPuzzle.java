package puzzle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import search.SearchProblem;
import search.Solver;

/**
 * A class to represent an instance of the eight-puzzle.
 * 
 * The spaces in an 8-puzzle are indexed as follows:
 * 
 * 0 | 1 | 2
 * --+---+---
 * 3 | 4 | 5
 * --+---+---
 * 6 | 7 | 8
 * 
 * The puzzle contains the eight numbers 1-8, and an empty space.
 * If we represent the empty space as 0, then the puzzle is solved
 * when the values in the puzzle are as follows:
 * 
 * 1 | 2 | 3
 * --+---+---
 * 4 | 5 | 6
 * --+---+---
 * 7 | 8 | 0
 * 
 * That is, when the space at index 0 contains value 1, the space 
 * at index 1 contains value 2, and so on.
 * 
 * From any given state, you can swap the empty space with a space 
 * adjacent to it (that is, above, below, left, or right of it,
 * without wrapping around).
 * 
 * For example, if the empty space is at index 2, you may swap
 * it with the value at index 1 or 5, but not any other index.
 * 
 * Only half of all possible puzzle states are solvable! See:
 * https://en.wikipedia.org/wiki/15_puzzle
 * for details.
 * 

 * @author liberato
 *
 */
public class EightPuzzle implements SearchProblem<List<Integer>> {
	
	// 0 represents an empty space.
	
		private final int LENGTH = 3;
		private final int WIDTH = 3;
		private Integer[][] startingBoard;
		
	/**
	 * Validates the input state. The board must have one of each of the integers from 0-8.
	 * 
	 * @param state
	 */
	private void validState(List<Integer> state) {
		
		// If the size of the list is not 9.
		if (state.size() != 9) {
			
			throw new IllegalArgumentException();
		}
		
		List<Integer> repeat = new ArrayList<>();
		
		// Only the values 0 - 8 are allowed in this list.
		for (Integer item : state) {
			
			// If the numbers are less than 0 or greater than 8, or have appeared more than once.
			if (item < 0 || item > 8) {
				
				// Throw exception.
				throw new IllegalArgumentException();
			}
			
			if (!repeat.contains(item)) {
				
				repeat.add(item);
			}
			
			else {
				
				throw new IllegalArgumentException();
			}
		}
	}

	/**
	 * Creates a new instance of the 8 puzzle with the given starting values.
	 * 
	 * The values are indexed as described above, and should contain exactly the
	 * nine integers from 0 to 8.
	 * 
	 * @param startingValues
	 *            the starting values, 0 -- 8
	 * @throws IllegalArgumentException
	 *             if startingValues is invalid
	 */
	public EightPuzzle(List<Integer> startingValues) {
		
		// Validate the starting state.
		this.validState(startingValues);
		
		// At this point our argument list has been validated.
		this.startingBoard = new Integer[LENGTH][WIDTH];
		this.startingBoard = this.convertToBoard(startingValues, this.startingBoard);
		
		//this.sucessorBoard = new ArrayList<>();
	
	}
	
	/**
	 * Returns a 2D representation of the state of the game, given a the state in list representation.
	 * 
	 * @param list
	 * @return Integer[][]
	 */
	private Integer[][] convertToBoard(List<Integer> state, Integer[][] board) {
		
		int count = 0;
		
		// Horizontal plane
		for (Integer[] length : board) {
			
			// Vertical Plane
			for (int i = 0; i < WIDTH; i++) {
				
				// Add the values to the board.
				length[i] = state.get(count);
				count++;
			}
		}
		
		return board;
	}
	
	private List<Integer> convertToList(Integer[][] board) {
		
		List<Integer> copy = new ArrayList<>();
		
		for (Integer[] item : board) {
			
			for (int i = 0; i < WIDTH; i++) {
				
				copy.add(item[i]);
			}
		}
		
		return copy;
	}
	
	private boolean isSolveable(List<Integer> state) {
		
		int inversions = 0;
		
		for (int i = 0; i < state.size(); i++) {
			
			for (int j = 0; j < state.size(); j++) {
				
				if (state.get(i) > state.get(j)) {
					
					inversions++;
				}
			}
		}
		
		if (inversions % 2 == 1) {
			
			return false;
		}
		
		return true;
	}

	@Override
	public List<Integer> getInitialState() {

		/*
		 * Should return a list of what the board contains from element 0 - 8.
		 */
		
		List<Integer> copy = new ArrayList<>();
		
		for (Integer[] item : this.startingBoard) {
			
			for (int i = 0; i < WIDTH; i++) {
				
				copy.add(item[i]);
			}
		}
		
		return copy;
	}

	// Should not change board state, it is merely creating copies of the board state to find successors.
	@Override
	public List<List<Integer>> getSuccessors(List<Integer> currentState) {
		// TODO
		
		/*
		 * 1. Need to locate 0.
		 * 2. If 0 is on the four corners, then it has only two successor moves.
		 * 3. If 0 is on the middle diamond, then it has only three successor moves.
		 * 4. If 0 is on the center, then is has a total of 4 successor moves.
		 */
		
		// Validate current state. We may have been passed a state that is not possible for this game.
		this.validState(currentState);
		
		List<Integer> copy = new ArrayList<>(currentState);
		
		// Translate the currentState to a board-like representation.
		Integer[][] currentBoard = new Integer[LENGTH][WIDTH];
		currentBoard = this.convertToBoard(currentState, currentBoard);
		
		// Get the location of 0 and use this information to determine the number of possible swaps.
		int x = this.locationOfZero(currentBoard).get(0);
		int y = this.locationOfZero(currentBoard).get(1);
		
		//check if solveable
//				if (!this.isSolveable(currentState)) {
//					
//					return new ArrayList<List<Integer>>();
//				}
		
		List<Integer[][]> successorBoard = new ArrayList<>();
		
		// In the most case for number of swaps, the coordinate of 0 is (1, 1). We have to make 4 swaps.
		if (x == 1 && y == 1) {
			
			// NORTH
			successorBoard.add(new Integer[LENGTH][WIDTH]);
			
			// SOUTH
			successorBoard.add(new Integer[LENGTH][WIDTH]);
			
			// EAST
			successorBoard.add(new Integer[LENGTH][WIDTH]);
			
			// WEST
			successorBoard.add(new Integer[LENGTH][WIDTH]);
	
			int count = 0;
			
			// Copy the original board into all the successors boards.
			for (int length = 0; length < LENGTH; length++) {
				
				for (int width = 0; width < WIDTH; width++) {
					
					successorBoard.get(0)[length][width] = copy.get(count);
					successorBoard.get(1)[length][width] = copy.get(count);
					successorBoard.get(2)[length][width] = copy.get(count);
					successorBoard.get(3)[length][width] = copy.get(count);
					count++;
				}
			} 
			
			this.swap(successorBoard.get(0), "NORTH", x, y);
			this.swap(successorBoard.get(1), "SOUTH", x, y);
			this.swap(successorBoard.get(2), "EAST", x, y);
			this.swap(successorBoard.get(3), "WEST", x, y);
		}
		
		// Checking the state where 3 moves is possible... change all starting from here
		else if ((x == 0 && y == 1) || (x == 1 && y == 0) || (x == 1 && y == 2) || (x == 2 && y == 1)) {
			
			successorBoard.add(new Integer[LENGTH][WIDTH]);
			successorBoard.add(new Integer[LENGTH][WIDTH]);
			successorBoard.add(new Integer[LENGTH][WIDTH]);
			int count = 0;
			
			// Copy the original board into all the successors boards.
			for (int length = 0; length < LENGTH; length++) {
				
				for (int width = 0; width < WIDTH; width++) {
					
					successorBoard.get(0)[length][width] = copy.get(count);
					successorBoard.get(1)[length][width] = copy.get(count);
					successorBoard.get(2)[length][width] = copy.get(count);
					count++;
				}
			}
			
			// Unable to move NORTH
			if (x == 0 && y == 1) {
				
				this.swap(successorBoard.get(0), "SOUTH", x, y);
				this.swap(successorBoard.get(1), "EAST", x, y);
				this.swap(successorBoard.get(2), "WEST", x, y);
			}
			
			// Unable to move WEST
			else if (x == 1 && y == 0) {
				
				this.swap(successorBoard.get(0), "NORTH", x, y);
				this.swap(successorBoard.get(1), "SOUTH", x, y);
				this.swap(successorBoard.get(2), "EAST", x, y);
			}
			
			// Unable to move EAST
			else if (x == 1 && y == 2) {
				
				this.swap(successorBoard.get(0), "NORTH", x, y);
				this.swap(successorBoard.get(1), "SOUTH", x, y);
				this.swap(successorBoard.get(2), "WEST", x, y);
			}
			
			// Unable to move SOUTH
			else {
				
				this.swap(successorBoard.get(0), "NORTH", x, y);
				this.swap(successorBoard.get(1), "EAST", x, y);
				this.swap(successorBoard.get(2), "WEST", x, y);
			}
		}
		
		// The last case, is when the state has only 2 possible swaps.
		else {
			
			successorBoard.add(new Integer[LENGTH][WIDTH]);
			successorBoard.add(new Integer[LENGTH][WIDTH]);
			int count = 0;
			
			// Copy the original board into all the successors boards.
			for (int length = 0; length < LENGTH; length++) {
				
				for (int width = 0; width < WIDTH; width++) {
					
					successorBoard.get(0)[length][width] = copy.get(count);
					successorBoard.get(1)[length][width] = copy.get(count);
					count++;
				}
			}
			
			// Unable to move NORTH and WEST
			if (x == 0 && y == 0) {
				
				this.swap(successorBoard.get(0), "SOUTH", x, y);
				this.swap(successorBoard.get(1), "EAST", x, y);
			}
			
			// Unable to move NORTH and EAST
			else if (x == 0 && y == 2) {
				
				this.swap(successorBoard.get(0), "SOUTH", x, y);
				this.swap(successorBoard.get(1), "WEST", x, y);
			}
			
			// Unable to move SOUTH and WEST
			else if (x == 2 && y == 0) {
				
				this.swap(successorBoard.get(0), "NORTH", x, y);
				this.swap(successorBoard.get(1), "EAST", x, y);
			}
			
			// Unable to move SOUTH and EAST
			else {
				
				this.swap(successorBoard.get(0), "NORTH", x, y);
				this.swap(successorBoard.get(1), "WEST", x, y);
			}
		}
		
		// Convert Integer[][] into List<Integer>
		List<List<Integer>> status = new ArrayList<>();
		List<Integer> list = new ArrayList<>();
		
		for (int i = 0; i < successorBoard.size(); i++) {
			
			list = this.convertToList(successorBoard.get(i));
			status.add(list);
		}
		
		System.out.println(status);
		
		return status;
	}
	
	/**
	 * Returns the board that has swapped places with the 0.
	 * 
	 * Passed in the current board to swap, direction to swap, and the coordinate of the 0.
	 * 
	 * @param board
	 * @param direction
	 * @param x
	 * @param y
	 * @return board
	 */
	public Integer[][] swap(Integer[][] board, String direction, int x, int y) {
		
		// Check x and y coordinates later...
		if (direction == "NORTH") {
			
			int temp = board[x][y];
			board[x][y] = board[x - 1][y];
			board[x - 1][y] = temp;
		}
		
		else if (direction == "SOUTH") {
			
			int temp = board[x][y];
			board[x][y] = board[x + 1][y];
			board[x + 1][y] = temp;
		}
		
		else if (direction == "EAST") {
			
			int temp = board[x][y];
			board[x][y] = board[x][y + 1];
			board[x][y + 1] = temp;
		}
		
		else if (direction == "WEST") {
			
			int temp = board[x][y];
			board[x][y] = board[x][y - 1];
			board[x][y - 1] = temp;
		}
		
		else {
			
			throw new IllegalArgumentException();
		}
		
		return board;
	}
	
	/**
	 * Returns a list of integers that holds two numbers: x and y coordinate.
	 * 
	 * The number of swaps possible depends on the position of 0.
	 * 
	 * @param currentState
	 * @return coordinate
	 */
	public List<Integer> locationOfZero(Integer[][] currentState) {
		
		List<Integer> coordinate = new ArrayList<>();
		boolean found = false;

		for (int length = 0; length < LENGTH && !found; length++) {
			
			for (int width = 0; width < WIDTH && !found; width++) {
				
				if (currentState[length][width] == 0) {
					
					coordinate.add(length);
					coordinate.add(width);
					found = true;
				}
			}
		}
		
		return coordinate;
	}
 
	@Override
	public boolean isGoal(List<Integer> state) {
		
		List<Integer> goal = Arrays.asList(new Integer[] {1, 2, 3, 4, 5, 6, 7, 8, 0});
		
		if (state.equals(goal)) {
			
			return true;
		}
		
		return false;
	}
	
	/**
	 * For visual purposes, helps display the state of the game.
	 */
	public void display(List<Integer> board) {
		
		System.out.println("Starting Board: ");
		for (Integer[] item : this.startingBoard) {
			
			for (int i = 0; i < WIDTH; i++) {
				
				System.out.print(item[i] + " ");
			}
			
			System.out.println();
		}
		
		List<List<Integer>> successorBoard = this.getSuccessors(board);
		
		System.out.println();
		System.out.println("Successor Boards: ");
		
		for (int i = 0; i < successorBoard.size(); i++) {
			
			for (Integer item : successorBoard.get(i)) {
				
				for (int j = 0; j < WIDTH; j++) {
					
					System.out.print(item + " ");
				}
				
				System.out.println();
			}
			
			System.out.println();
		}
	}
	
	/**
	 * Displays a select board.
	 * 
	 * @param b
	 */
	public void displayBoard(Integer[][] b) {
		
		for (int i = 0; i < LENGTH; i++) {
			
			for (int j = 0; j < WIDTH; j++) {
				
				System.out.print(b[i][j] + " ");
			}
			
			System.out.println();
		}
	}

	public static void main(String[] args) {
		EightPuzzle e = new EightPuzzle(Arrays.asList(new Integer[] { 1, 2, 3,
				4, 0, 6, 7, 5, 8 }));

		List<List<Integer>> r = new Solver<List<Integer>>(e).solveWithBFS();
		for (List<Integer> l : r) {
			System.out.println(l);
		}
	}
}
