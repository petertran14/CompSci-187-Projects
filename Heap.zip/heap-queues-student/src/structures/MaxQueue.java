package structures;

import comparators.IntegerComparator;

import java.util.Comparator;
import java.util.Iterator;

public class MaxQueue<V> implements PriorityQueue<Integer, V> {
	
	private StudentArrayHeap<Integer, V> heap;
	private int size;
	IntegerComparator comparator;
	
	public MaxQueue() {
		
		this.heap = new StudentArrayHeap<Integer, V>(comparator);
		this.size = 0;
	}

	@Override
	public PriorityQueue<Integer, V> enqueue(Integer priority, V value) {
		
		if (priority == null || value == null) {
			
			throw new NullPointerException();
		}
		
		this.heap.add(priority, value);
		this.size++;
		
		return this;
	}

	@Override
	public V dequeue() {
		// TODO Auto-generated method stub
		if (this.isEmpty()) {
			
			throw new IllegalStateException();
		}
		
		return this.heap.remove();
	}

	@Override
	public V peek() {
		// TODO Auto-generated method stub
		return this.heap.peek();
	}

	@Override
	public Iterator<Entry<Integer, V>> iterator() {
		// TODO Auto-generated method stub
		return this.heap.asList().iterator();
	}

	@Override
	public Comparator<Integer> getComparator() {
		// TODO Auto-generated method stub
		return this.heap.getComparator();
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return this.size;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return this.size == 0;
	}
}
