package structures;

import comparators.IntegerComparator;
import comparators.ReverseIntegerComparator;

import java.util.Comparator;
import java.util.Iterator;

public class MinQueue<V> implements PriorityQueue<Integer, V> {
	
	private StudentArrayHeap<Integer, V> heap;
	private int size;
	ReverseIntegerComparator comparator;
	
	public MinQueue() {
		
		this.heap = new StudentArrayHeap<>(comparator);
		this.size = 0;
	}

	@Override
	public PriorityQueue<Integer, V> enqueue(Integer priority, V value) {
		
		if (priority == null || value == null) {
			
			throw new NullPointerException();
		}
		
		this.heap.add(priority, value);
		this.size++;
		
		return this;
	}

	@Override
	public V dequeue() {
		
		if (this.isEmpty()) {
			
			throw new IllegalStateException();
		}
		
		return this.heap.remove();
	}

	@Override
	public V peek() {
		
		// TODO Auto-generated method stub
		if (this.isEmpty()) {
			
			throw new IllegalStateException();
		}
		
		return this.heap.peek();
	}

	@Override
	public Iterator<Entry<Integer, V>> iterator() {
		// TODO Auto-generated method stub
		return this.heap.asList().iterator();
	}

	@Override
	public Comparator<Integer> getComparator() {
		// TODO Auto-generated method stub
		return this.heap.getComparator();
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return this.size;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return this.size == 0;
	}
}

