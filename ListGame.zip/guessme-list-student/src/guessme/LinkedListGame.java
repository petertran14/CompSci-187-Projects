package guessme;

/**
 * A LinkedList-based implementation of the Guess-A-Number game
 */
public class LinkedListGame {

	// TODO: declare data members as necessary
	
	private LLIntegerNode headCandidate;
	private LLIntegerNode tailCandidate;
	
	private LLIntegerNode headPriorGuess;
	private LLIntegerNode tailPriorGuess;
	
	private int guess;
	
	// Stores state of the game.
	private boolean gameOver;

	
	/********************************************************
	 * NOTE: for this project you must use linked lists
	 * implemented by yourself. You are NOT ALLOWED to use
	 * Java arrays of any type, or any class in the java.util
	 * package (such as ArrayList).
	 *******************************************************/	 
	
	/********************************************************
	 * NOTE: you are allowed to add new methods if necessary,
	 * but DO NOT remove any provided method, and do NOT add
	 * new files (as they will be ignored by the autograder).
	 *******************************************************/
	
	// LinkedListGame constructor method
	public LinkedListGame() {
		
		this.headCandidate = null;
		this.tailCandidate = null;
		
		this.headPriorGuess = null;
		this.tailPriorGuess = null;
		
		this.gameOver = false;
		this.guess = 1000;
		
		// We need to fill our candidate llist with values from 1000 to 9999 inclusive.
		for (int i = 0; i < 9000; i++) {
			
			this.addToCandidateList(i + 1000);
		}
	}
	
	/**
	 * Returns true or false, whether or not the candidate number list is empty.
	 * 
	 * @return boolean
	 */
	public boolean isEmptyCandidateNumbers() {
		
		// If head is null then the candidate list contains no numbers.
		if (this.headCandidate == null) {
			
			return true;
		}
		
		return false;
	}
	
	/**
	 * Returns true or false, whether or not the candidate number list is empty.
	 * 
	 * @return boolean
	 */
	public boolean isEmptyPriorGuesses() {
		
		// If head is null then the prior guess list contains no numbers.
		if (this.headPriorGuess == null) {
			
			return true;
		}
		
		return false;
	}
	
	/**
	 * Returns the size of the candidate numbers list.
	 * 
	 * For testing purposes only.
	 * 
	 * @return int
	 */
	public int getSizeCandidateNumbers() {
		
		int size = 0;
		LLIntegerNode copy = this.headCandidate;
		
		while (copy != null) {
			
			copy = copy.getLink();
			size++;
		}
		
		return size;
	}
	
	/**
	 * Inserts an integer to the end of the linked list.
	 * 
	 * @param value
	 */
	public void addToCandidateList(int value) {
		
		// If this is the first insertion.
		if (this.isEmptyCandidateNumbers()) {
			
			// Head and tail point to the same node.
			this.headCandidate = new LLIntegerNode(value);
			this.tailCandidate = this.headCandidate;
		}
		
		// If this is not the first insertion.
		else {
			
			// Instantiate a new node that tail will point to.
			this.tailCandidate.setLink(new LLIntegerNode(value));
			
			// Make tail the last node.
			this.tailCandidate = this.tailCandidate.getLink();
		}
	}
	
	public void addToPriorGuesses(int value) {
		
		// If this is the first insertion.
		if (this.isEmptyPriorGuesses()) {
			
			// Head and tail point to the same node.
			this.headPriorGuess = new LLIntegerNode(value);
			this.tailPriorGuess = this.headPriorGuess;
		}
		
		else {
			
			// Instantiate a new node that tail will point to.
			this.tailPriorGuess.setLink(new LLIntegerNode(value));
			
			// Make tail reference the last node.
			this.tailPriorGuess = this.tailPriorGuess.getLink();
		}
	}
	
	// Resets data members and game state so we can play again
	public void reset() {
		
		// By setting head to null, we have broken the link with the previous llist. Java will delete the previous data.
		this.headCandidate = null;
		this.tailCandidate = null;
		
		this.headPriorGuess = null;
		this.tailPriorGuess = null;
		
		this.gameOver = false;
		this.guess = 1000;
		
		// We need to fill our candidate llist with values from 1000 to 9999 inclusive.
		for (int i = 0; i < 9000; i++) {
			
			this.addToCandidateList(i + 1000);
		}
	}
	
	// Returns true if n is a prior guess; false otherwise.
	public boolean isPriorGuess(int n) {
		
		// If the prior guess list is null, then there can be no prior guess.
		if (this.isEmptyPriorGuesses()) {
			
			return false;
		}
		
		// Use a temp variable for traversing.
		LLIntegerNode copy = this.headPriorGuess;
		
		// Traverse the prior guess list.
		while (copy != null) {
			
			// If there was a value in the list equal to n, then it is a prior guess.
			if (copy.getInfo() == n) {
				
				return true;
			}
			
			// Traverse to next node.
			copy = copy.getLink();
		}
		
		return false;
		
	}
	
	// Returns the number of guesses so far.
	public int numGuesses() {
		
		// If the prior guess list is empty, there have been no guesses.
		if (this.isEmptyPriorGuesses()) {
			
			return 0;
		}
		
		// Otherwise, traverse the list and store the size in an accumulator.
		LLIntegerNode copy = this.headPriorGuess;
		int size = 0;
		
		while (copy != null) {
			
			copy = copy.getLink();
			size++;
		}
		
		return size;
	}
	
	/**
	 * Returns the number of matches between integers a and b.
	 * You can assume that both are 4-digits long (i.e. between 1000 and 9999).
	 * The return value must be between 0 and 4.
	 * 
	 * A match is the same digit at the same location. For example:
	 *   1234 and 4321 have 0 match;
	 *   1234 and 1114 have 2 matches (1 and 4);
	 *   1000 and 9000 have 3 matches (three 0's).
	 */
	public static int numMatches(int a, int b) {
		// Keeps track of the number of matches.
		int matches = 0;
		
		while (a != 0) {
			
			// If the digits match, increment.
			if ((a % 10) == (b % 10)) {
				
				matches++;
			}
			
			// Shrink down the number.
			a = a / 10;
			b = b / 10;
		}
		
		return matches;
	}
	
	/**
	 * Returns true if the game is over; false otherwise.
	 * The game is over if the number has been correctly guessed
	 * or if no candidate is left.
	 */
	public boolean isOver() {
		
		return this.gameOver;
	}
	
	/**
	 * Returns the guess number and adds it to the list of prior guesses.
	 * The insertion should occur at the end of the prior guesses list,
	 * so that the order of the nodes follow the order of prior guesses.
	 */	
	public int getGuess() {
		// TODO: add guess to the list of prior guesses.
		
		this.addToPriorGuesses(this.guess);
		return this.guess;
	}
	
	/**
	 * Updates guess based on the number of matches of the previous guess.
	 * If nmatches is 4, the previous guess is correct and the game is over.
	 * Check project description for implementation details.
	 * 
	 * Returns true if the update has no error; false if no candidate 
	 * is left (indicating a state of error);
	 */
	public boolean updateGuess(int nmatches) {
		
		// If the host indicates we have found the number
		if (nmatches == 4) {
			
			this.gameOver = true;
			return true;
		}
		
		LLIntegerNode copy = this.headCandidate;
		
		// This is the new candidate list.
		LLIntegerNode newHead = null;
		LLIntegerNode newTail = null;
		
		// Cycle through possible candidates.
		while (copy != null) {
			
			// If the matches is identical to nmatches
			if (LinkedListGame.numMatches(copy.getInfo(), this.guess) == nmatches) {
				
				// Add the potential candidate to the new list.
				if (newHead == null) {
					
					newHead = new LLIntegerNode(copy.getInfo());
					newTail = newHead;
				}
				
				else {
					
					newTail.setLink(new LLIntegerNode(copy.getInfo()));
					newTail = newTail.getLink();
				}
			}
			
			copy = copy.getLink();
		}
		
		// If the new list is empty, then there is an error.
		if (newHead == null) {
			
			this.gameOver = true;
			return false;
		}
		
		// Have the original candidate head and tail point to the new ones.
		this.headCandidate = newHead;
		this.tailCandidate = newTail;
		
		// Update the guess.
		this.guess = this.headCandidate.getInfo();
		
		return true;
	}
	
	// Returns the head of the prior guesses list.
	// Returns null if there hasn't been any prior guess
	public LLIntegerNode priorGuesses() {
		// TODO
		
		if (this.isEmptyPriorGuesses()) {
			
			return null;
		}
		
		return this.headPriorGuess;
	}
	
	/**
	 * Returns the list of prior guesses as a String. For example,
	 * if the prior guesses are 1000, 2111, 3222, in that order,
	 * the returned string should be "1000, 2111, 3222", in the same order,
	 * with every two numbers separated by a comma and space, except the
	 * last number (which should not be followed by either comma or space).
	 *
	 * Returns an empty string if here hasn't been any prior guess
	 */
	public String priorGuessesString() {
		// TODO
		
		if (this.isEmptyPriorGuesses()) {
			
			return new String();
		}
		
		String s = new String();
		
		LLIntegerNode copy = this.headPriorGuess;
		
		while (copy != null) {
			
			s = s + copy.getInfo();

			if (copy.getLink() != null) {
				
				s = s + ", ";
			}
			
			copy = copy.getLink();
		}
		
		return s;
	}
	
}
