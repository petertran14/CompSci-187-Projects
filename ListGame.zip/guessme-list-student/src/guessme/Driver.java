package guessme;

public class Driver {

	public static void main(String[] args) {
		
//		int[] array = new int[5];
//		
//		for (int i = 0; i < 5; i++) {
//			
//			array[i] = i;
//		}
//		
//		String s = "(";
//		
//		for (int i = 0; i < 5; i++) {
//			
//			s = s.concat(Integer.toString(array[i]));
//			
//			if (i != array.length - 1) {
//				
//				s = s.concat(", ");
//			}
//		}
//		
//		s = s.concat(")");
//		
//		System.out.println(s);
		
		int num = 5;
		
		String s = new String("foo");
		
		s = s + num;
		
		System.out.println(s);
	}
}
