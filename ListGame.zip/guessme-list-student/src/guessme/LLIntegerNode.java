package guessme;

/**
 * This class defines a linked list node storing an integer.
 * Use primitive type int (do not use wrapper class Integer)
 * You must provide the following methods:
 * - a constructor
 * - a setInfo method and a getInfo method
 * - a setLink method and a getLink method
 */
public class LLIntegerNode {
	// TODO
	
	private int value;
	private LLIntegerNode next;
	
	public LLIntegerNode(int value) {
		
		this.value = value;
		this.next = null;
	}
	
	/**
	 * Sets the value of the current node.
	 * 
	 * @param value
	 */
	public void setInfo(int value) {
		
		this.value = value;
	}
	
	/**
	 * Sets the current node to point to the next node.
	 * 
	 * @param next
	 */
	public void setLink(LLIntegerNode next) {
		
		this.next = next;
	}
	
	/**
	 * Returns the value stored in the node.
	 * 
	 * @return int
	 */
	public int getInfo() {
		
		return this.value;
	}
	
	/**
	 * Returns the node that the current node references.
	 * 
	 * @return LLIntegerNode
	 */
	public LLIntegerNode getLink() {
		
		return this.next;
	}
}

