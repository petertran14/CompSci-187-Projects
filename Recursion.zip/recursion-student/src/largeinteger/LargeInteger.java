package largeinteger;

import largeinteger.LLNode;

/** The LargeInteger class
 *  This class represents a large, non-negative integer using a linked list.
 *  Each node stores a single digit. The nodes represent all digits in *reverse* order:
 *  the least significant digit is the first node, and the most significant the last node.
 *  For example, 135642 is represented as 2->4->6->5->3->1 in that order.
 */
public class LargeInteger {
	private LLNode<Integer> head;	// head of the list
	private LLNode<Integer> tail;
	private int size;				// size (i.e. number of digits
	
	// Returns size
	public int size() { return size; }
	// Returns the linked list (used only for JUnit test purpose)
	public LLNode<Integer> getList() { return head; }
	
	public LargeInteger() {
		head = null; size = 0;
	}
	
	/** Constructor that takes a String as input and constructs the linked list.
	 *  You can assume that the input is guaranteed to be valid: i.e. every character
	 *  in the string is between '0' and '9', and the first character is never '0'
	 *  (unless '0' is the only character in the string). You can use input.charAt(i)-'0'
	 *  to convert the character at index i to the integer value of that digit.
	 *  Remember: the list nodes must be in reverse order as the characters in the string.
	 */
	public LargeInteger(String input) {
		
		// If the input contains stuff...
		if (!input.isEmpty()) {
			
			// First case...
			this.head = new LLNode<Integer>(input.charAt(input.length() - 1)-'0', null);
			this.tail = this.head;
			this.size++;
		
			// The rest of the cases are the same...
			for (int i = input.length() - 2; i >= 0; i--) {
				
				this.tail.link = new LLNode<Integer>(input.charAt(i)-'0', null);
				this.tail = this.tail.link;
				this.size++;
			}
		}
	}
	
	/** Divide *this* large integer by 10 and return this.
	 *  Assume integer division: for example, 23/10 = 2, 8/10 = 0 and so on.
	 *  
	 *  Does not return a new LargeInteger object, but modifies and returns the existing list.
	 */
	public LargeInteger divide10() {
		// TODO
		
		// If our integer is from 0-9...
		if (this.size == 1) {
			
			this.remove(0);
			
			// Replaces the previous node with a node containing 0.
			this.head = new LLNode<Integer>(0, null);
			this.size++;
		}
		
		else {
			
			this.remove(0);
		}
		
		return this;
	}
	
	/**
	 * Removes and Returns the Integer at the given index from the this list.
	 * 
	 * @param i
	 * @return Integer
	 * @throws Exception
	 */
	public Integer remove(int i) {
		
		if (this.size == 0 || i < 0 || i >= this.size) {
			
			return -1;
		}
		
		Integer num = 0;
		
		// If there is only one node in the list.
		if (this.size == 1) {
			
			num = this.head.data;
			this.head = this.tail = null;
		}
		
		// PopFront
		else if (i == 0) {
			
			num = this.head.data;
			LLNode<Integer> garbage = this.head;
			this.head = this.head.link;
			garbage.link = null;
		}
		
		// PopBack
		else if (i == this.size - 1) {
			
			LLNode<Integer> temp = this.head;
			
			while (temp.link.link != null) {
				
				temp = temp.link;
			}
			
			num = temp.link.data;
			temp.link = null;
			this.tail = temp;
		}
		
		// Middle Removal
		else {
			
			LLNode<Integer> temp = this.head;
			
			// Stop one node behind the target node.
			for (int count = 0; count < i - 1; count++) {
				
				temp = temp.link;
			}
			
			num = temp.link.data;
			LLNode<Integer> garbage = temp.link;
			temp = temp.link.link;
			garbage.link = null;
		}
		
		this.size--;
		
		return num;
	}
	
	/** Multiply *this* large integer by 10 and return this.
	 *  For example, 23*10 = 230, 0*10 = 0 etc.
	 */
	public LargeInteger multiply10() {
		// TODO
		
		// Any multiplication with 0 is 0.
		if (this.head.data == 0) {
			
			return this;
		}
		
		// Multiplying by 10 adds a 0 to the end of any number that isn't 0.
		this.pushFront(0);
		
		return this;
	}
	
	/**
	 * Pushes to the head of the list, a number.
	 * 
	 * Since our list in storing numbers in reverse, pushing to the front is
	 * equivalent to adding more numbers to the end of the list when it is printed out.
	 * 
	 * @param num
	 */
	public void pushFront(int num) {
		
		if (this.size == 0) {
			
			this.head = new LLNode<Integer>(num, null);
			this.tail = this.head;
		}
		
		else {
			
			LLNode<Integer> newNode = new LLNode<Integer>(num, this.head);
			this.head = newNode;
		}
		
		this.size++;
	}
	
	/**
	 * Pushes a new node to the tail of the list.
	 * 
	 * This function is useful for the add function, which we need to push back elements onto the list.
	 * 
	 * @param num
	 */
	public void pushBack(int num) {
		
		if (this.size == 0) {
			
			this.head = new LLNode<Integer>(num, null);
			this.tail = this.head;
		}
		
		else {
			
			this.tail.link = new LLNode<Integer>(num, null);
			this.tail = this.tail.link;
		}
		
		this.size++;
	}
	
	/** Returns a *new* LargeInteger object representing the sum of this large integer
	 *  and another one (given by that). Your code must correctly handle cases such as
	 *  the two input integers have different sizes (e.g. 2+1000=1002), or there is a
	 *  carry over at the highest digit (e.g. 9999+2=10001).
	 */
	public LargeInteger add(LargeInteger that) {
		// TODO
		
		// Case where this list is empty.
		if (this.size == 0) {
			
			return new LargeInteger(that.toString());
		}
		
		// Case where that list is empty.
		if (that.size == 0) {
			
			return new LargeInteger(this.toString());
		}
		
		// Need a new list to store the result.
		LargeInteger list = new LargeInteger();
		
		// Tools of Traversement.
		LLNode<Integer> thisTemp = this.head;
		LLNode<Integer> thatTemp = that.head;
		int carry = 0;
		
		while (thisTemp != null && thatTemp != null) {
			
			int num = thisTemp.data + thatTemp.data + carry;
			
			if (num == 10) {
				
				list.pushBack(0);
			}
			
			else {
				
				list.pushBack((num) % 10);
			}
			
			carry = 0;
			
			// Indicates that the addition resulted in a number of 10 or greater and we need to carry over the 1.
			if (num / 10 == 1) {
				
				carry = 1;
			}
			
			thisTemp = thisTemp.link;
			thatTemp = thatTemp.link;
		}
		
		// Both of the lists are the same size, but we have carry over.
		if (this.size == that.size && carry == 1) {
			
			// Allocate a new node to the end of the list
			list.pushBack(carry);
		}
		
		// The this list is bigger, so it just get copied into the return list. Check the carry value as well.
		else if (this.isBigger(that)) {
			
			while (thisTemp != null) {
				
				int num = thisTemp.data + carry;
				
				if (num == 10) {
					
					list.pushBack(0);
				}
				
				else {
					
					list.pushBack((num) % 10);
				}
				
				carry = 0;
				
				if (num / 10 == 1) {
					
					carry = 1;
				}
				
				thisTemp = thisTemp.link;
			}
			
			if (carry == 1) {
				
				list.pushBack(carry);
			}
		}
		
		// The that list is bigger, so it just get copied into the return list. Check the carry value as well.
		else if (!this.isBigger(that)) {
			
			while (thatTemp != null) {
				
				int num = thatTemp.data + carry;
				
				if (num == 10) {
					
					list.pushBack(0);
				}
				
				else {
					
					list.pushBack((num) % 10);
				}
				
				carry = 0;
				
				if (num / 10 == 1) {
					
					carry = 1;
				}
				
				thatTemp = thatTemp.link;
			}
			
			if (carry == 1) {
				
				list.pushBack(carry);
			}
		}
 		
		return list;
	}
	
	public boolean isBigger(LargeInteger that) {
		
		if (this.size > that.size) {
			
			return true;
		}
		
		return false;
	}
	
	/** Returns a new LargeInteger object representing the result of multiplying
	 *  this large integer with a non-negative integer x. You can assume x is either
	 *  a positive integer or 0. Hint: you can use a loop and call the 'add' method
	 *  above to accomplish the 'multiply'.
	 */
	public LargeInteger multiply(int x) {
		// TODO
		
		// If the list is empty, return the empty list.
		if (this.size == 0) {
			
			return new LargeInteger();
		}
		
		// If we are multiplying by 0, return a new list that only 0 in it.
		if (x == 0) {
			
			return new LargeInteger("0");
		}
		
		LargeInteger list = new LargeInteger();
		
		for (int i = 0; i < x; i++) {
			
			list = list.add(this);
		}
		
		return list;
	}

	/** Recursive method that converts the list referenced by curr_node back to
	 *  a string representing the integer. Think about what's the base case and
	 *  what it should return. Then think about what it should return in non-base case.
	 *  Hint: refer to the 'printing a list backwards' example we covered in lectures.
	 */
	private String toString(LLNode<Integer> curr_node) {
		// TODO
		
		// Base case, where we have reached the last element in the list.
		if (curr_node.link == null) {
			
			// Return a string representation of the list.
			return curr_node.data.toString();
		}
		
		// Making progress to the end of the list.
		return toString(curr_node.link) + curr_node.data.toString();
	}
	
	/** Convert this list back to a string representing the large integer.
	 *  This is a public method that jump-starts the call to the recursive method above.
	 */
	public String toString() {
		return toString(head);
	}
	
	// Recursive method to compute factorial
	public static LargeInteger factorial(int n) {
		if(n==0) return new LargeInteger("1");
		return factorial(n-1).multiply(n);
	}
	
	// Recursive method to compute power
	public static LargeInteger pow(int x, int y) {
		if(y==0) return new LargeInteger("1");
		return pow(x, y-1).multiply(x);
	}
}
