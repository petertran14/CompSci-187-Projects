package largeinteger;

public class Driver {

	public static void main(String args[]) {
		
		String s = "123";
		String p = "456";
		
		System.out.println(6%10);
	}
}
