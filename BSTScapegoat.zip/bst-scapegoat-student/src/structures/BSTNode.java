package structures;

/**
 * A node in a BST.
 * 
 * Note that BSTNode MUST implement BSTNodeInterface; removing this will result
 * in your program failing to compile for the autograder.
 * 
 * @author liberato
 *
 * @param <T>
 */
public class BSTNode<T extends Comparable<T>> implements BSTNodeInterface<T> {
	private T data;
	private BSTNode<T> parent;
	private BSTNode<T> left;
	private BSTNode<T> right;

	public BSTNode(T data, BSTNode<T> left, BSTNode<T> right) {
		this.parent = null;
		this.data = data;
		this.left = left;
		this.right = right;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public BSTNode<T> getLeft() {
		return left;
	}

	public void setLeft(BSTNode<T> left) {
		
		// This is the current node, so parent is the current node behind the child.
		this.left = left;
		
		if (left != null) {
			
			left.parent = this;
		}
	}

	public BSTNode<T> getRight() {
		
		return right;
	}

	public void setRight(BSTNode<T> right) {
		
		// This is the current node, so parent is the current node behind the child.
		this.right = right;
		
		if (right != null) {
			
			right.parent = this;
		}
	}
	
	/**
	 * Given the current (this) node, we can find its parent.
	 * @return parent node.
	 */
	public BSTNode<T> getParent() {
		
		return this.parent;
	}
	
	public void setParent(BSTNode<T> parent) {
		
		this.parent = parent;
	}
}