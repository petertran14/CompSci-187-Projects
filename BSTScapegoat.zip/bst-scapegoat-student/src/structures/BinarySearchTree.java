package structures;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class BinarySearchTree<T extends Comparable<T>> implements
		BSTInterface<T> {
	protected BSTNode<T> root;
	
//	public BinarySearchTree(BSTNode<T> root) {
//		
//		this.root = root;
//	}

	public boolean isEmpty() {
		return root == null;
	}

	public int size() {
		return subtreeSize(root);
	}

	protected int subtreeSize(BSTNode<T> node) {
		if (node == null) {
			return 0;
		} else {
			return 1 + subtreeSize(node.getLeft())
					+ subtreeSize(node.getRight());
		}
	}

	public boolean contains(T t) {
		// TODO
		
		if (t == null) {
			
			throw new NullPointerException();
		}
		
		return contains(t, this.root);
	}
	
	protected boolean contains(T t, BSTNode<T> node) {
		
		// Base case, if t is not found.
		if (node == null) {
			
			return false;
		}
		
		// Base case, if t is found.
		if (this.get(node.getData()).equals(t)) {
			
			return true;
		}
		
		// Traverse left.
		if (t.compareTo(node.getData()) < 0) {
			
			return contains(t, node.getLeft());
		}
		
		// Traverse right.
		return contains(t, node.getRight());
	}

	public boolean remove(T t) {
		if (t == null) {
			throw new NullPointerException();
		}
		boolean result = contains(t);
		if (result) {
			root = removeFromSubtree(root, t);
		}
		return result;
	}

	private BSTNode<T> removeFromSubtree(BSTNode<T> node, T t) {
		// node must not be null
		int result = t.compareTo(node.getData());
		if (result < 0) {
			node.setLeft(removeFromSubtree(node.getLeft(), t));
			return node;
		} else if (result > 0) {
			node.setRight(removeFromSubtree(node.getRight(), t));
			return node;
		} else { // result == 0
			if (node.getLeft() == null) {
				return node.getRight();
			} else if (node.getRight() == null) {
				return node.getLeft();
			} else { // neither child is null
				T predecessorValue = getHighestValue(node.getLeft());
				node.setLeft(removeRightmost(node.getLeft()));
				node.setData(predecessorValue);
				return node;
			}
		}
	}

	private T getHighestValue(BSTNode<T> node) {
		// node must not be null
		if (node.getRight() == null) {
			return node.getData();
		} else {
			return getHighestValue(node.getRight());
		}
	}

	private BSTNode<T> removeRightmost(BSTNode<T> node) {
		// node must not be null
		if (node.getRight() == null) {
			return node.getLeft();
		} else {
			node.setRight(removeRightmost(node.getRight()));
			return node;
		}
	}

	public T get(T t) {
		// TODO
		
		// If the element to search for is null, throw an exception.
		if (t == null) {
			
			throw new NullPointerException();
		}
		
		return get(t, this.root);
	}
	
	protected T get(T t, BSTNode<T> node) {
		
		// Base case, if we do not find the element, then return null.
		if (node == null) {
			
			return null;
		}
		
		// Base case, if we do find the element, return the element.
		if (t.compareTo(node.getData()) == 0) {
			
			return t;
		}
		
		// Recursive case, if t is less than the current node's data, traverse to the node's left child.
		if (t.compareTo(node.getData()) < 0) {
			
			return get(t, node.getLeft());
		}
			
		// Recursive case, if t is greater than the current node's data, traverse to the node's right child.
		return get(t, node.getRight());
	}
	
	/**
	 * Returns the node with the data.
	 * 
	 * @param t
	 * @param node
	 * @return target node.
	 */
	public BSTNode<T> getNode(T t, BSTNode<T> node) {
		
		// Base case, if we do not find the element, then return null.
		if (node == null) {
			
			return null;
		}
		
		// Base case, if we do find the element, return the element.
		if (t.compareTo(node.getData()) == 0) {
			
			return node;
		}
		
		// Recursive case, if t is less than the current node's data, traverse to the node's left child.
		if (t.compareTo(node.getData()) < 0) {
			
			return getNode(t, node.getLeft());
		}
			
		// Recursive case, if t is greater than the current node's data, traverse to the node's right child.
		return getNode(t, node.getRight());
	}


	public void add(T t) {
		if (t == null) {
			throw new NullPointerException();
		}
		root = addToSubtree(root, new BSTNode<T>(t, null, null));
	}

	public BSTNode<T> addToSubtree(BSTNode<T> node, BSTNode<T> toAdd) {
		if (node == null) {
			return toAdd;
		}
		int result = toAdd.getData().compareTo(node.getData());
		if (result <= 0) {
			node.setLeft(addToSubtree(node.getLeft(), toAdd));
		} else {
			node.setRight(addToSubtree(node.getRight(), toAdd));
		}
		return node;
	}

	@Override
	public T getMinimum() {
		// TODO
		
		if (this.isEmpty()) {
			
			return null;
		}
		
		return this.getMinimum(this.root);
	}

	protected T getMinimum(BSTNode<T> node) {
		
		// Base case, if the left child is null, then we are sure this current node has the minimum value.
		if (node.getLeft() == null) {
			
			return node.getData();
		}
		
		// Recursive case, traverse to the left child of the current node.
		return this.getMinimum(node.getLeft());
	}

	@Override
	public T getMaximum() {
		// TODO
		
		if (this.isEmpty()) {
			
			return null;
		}
		
		return this.getMaximum(this.root);
	}

	protected T getMaximum(BSTNode<T> node) {
		
		// Base case, the max node is on the right most side.
		if (node.getRight() == null) {
			
			return node.getData();
		}
		
		// Traverse.
		return this.getMaximum(node.getRight());
	}
	
	@Override
	public int height() {
		// TODO
		
		// According to the documentation.
		if (this.isEmpty()) {
			
			return -1;
		}
		
		return height(this.root);
	}

	protected int height(BSTNode<T> node) {
		
		// If the tree is empty, return a flag int.
		if (this.isEmpty()) {
			
			return -1;
		}
		
		// Base case, if node is null, return -1, to cancel the extra one at the end.
		if (node == null) {
			
			return -1;
		}
		
		int left = 1 + height(node.getLeft());
		int right = 1 + height(node.getRight());
		
		if (left > right) {
			
			return left;
		}
		
		return right;
	}

	public Iterator<T> preorderIterator() {
		// TODO
		
		Queue<T> queue = new LinkedList<T>();
		preorderTraverse(queue, this.root);
		return queue.iterator();
	}
	
	// Pre-order visits the current node, then the left, then the right.
	protected void preorderTraverse(Queue<T> queue, BSTNode<T> node) {
		
		if (node != null) {
			
			queue.add(node.getData());
			preorderTraverse(queue, node.getLeft());
			preorderTraverse(queue, node.getRight());
		}
	}


	public Iterator<T> inorderIterator() {
		Queue<T> queue = new LinkedList<T>();
		inorderTraverse(queue, root);
		return queue.iterator();
	}
	
	public Iterator<T> inorderIterator(BSTNode<T> node) {
		
		Queue<T> queue = new LinkedList<T>();
		inorderTraverse(queue, node);
		return queue.iterator();
	}


	private void inorderTraverse(Queue<T> queue, BSTNode<T> node) {
		if (node != null) {
			inorderTraverse(queue, node.getLeft());
			queue.add(node.getData());
			inorderTraverse(queue, node.getRight());
		}
	}

	public Iterator<T> postorderIterator() {
		// TODO
		
		Queue<T> queue = new LinkedList<T>();
		postorderTraverse(queue, this.root);
		return queue.iterator();
	}
	
	// Post-order visits the left, then the right, then the current.
	protected void postorderTraverse(Queue<T> queue, BSTNode<T> node) {
		
		if (node != null) {
			
			postorderTraverse(queue, node.getLeft());
			postorderTraverse(queue, node.getRight());
			queue.add(node.getData());
		}
	}


	@Override
	public boolean equals(BSTInterface<T> other) {
		// TODO
		
		if (other == null) {
			
			throw new NullPointerException();
		}
		
		if (this.isEmpty() && other.isEmpty()) {
			
			return true;
		}
		
		return this.equals(this.root, other.getRoot());
	}
	
	protected boolean equals(BSTNode<T> curr, BSTNode<T> other) {
		
		// Prevent NULL EXCEPTIONS!!
		if (curr == null && other == null) {
			
			return true;
		}
		
		if (curr != null && other != null) {
			
			// This if statement must be true always for the trees to be identical
			if (curr.getData().equals(other.getData()) && equals(curr.getLeft(), other.getLeft()) && equals(curr.getRight(), other.getRight())) {
				
				return true;
			}
		}
		
		return false;
	}

	@Override
	public boolean sameValues(BSTInterface<T> other) {
		// TODO
	
		if (other == null) {
			
			throw new NullPointerException();
		}
		
		// Instantiate two queues to hold the in order traversal of the two BST's.
		Queue<T> queue1 = new LinkedList<T>();
		Queue<T> queue2 = new LinkedList<T>();
		
		// Traverse the two trees and store the ordering in the queues.
		this.inorderTraverse(queue1, this.getRoot());
		this.inorderTraverse(queue2, other.getRoot());
	
		// If the queues are not equal in size, then they have different values.
		if (queue1.size() != queue2.size()) {
			
			return false;
		}
		
		// Loop through the queues, and compare each item.
		while (!queue1.isEmpty()) {
			
			T item1 = queue1.remove();
			
			// If the data in queue1 is not shared in queue2, then the trees do not have the same values.
			if (!queue2.contains(item1)) {
				
				return false;
			}
		}
		
		return true;
	}

	/**
	 * For this project, a tree is considered balanced when 2^h ≤ n < 2^(h+1), where h is the tree’s
	   height, and n its size.
	 */
	@Override
	public boolean isBalanced() {
		// TODO
		
		// An empty tree is considered balanced.
		if (this.isEmpty()) {
			
			return true;
		}
		
		// Specification for being a balanced tree.
		if (this.size() >= Math.pow(2, this.height()) && this.size() < Math.pow(2, this.height() + 1)) {
			
			return true;
		}
		
		return false;
	}

	/**
	 * Do an inorderTraversal on the BST, and store it in a array/queue. Pick the middle element, then
	 * recurse over the left side and right side.
	 */
	@Override
    @SuppressWarnings("unchecked")
	public void balance() {
		
		// TODO
		
//		if (this.isEmpty()) {
//			
//			this.root = new BSTNode<T>();
//		}
		
		T[] array = (T[]) new Comparable[this.size()];
		
		this.inOrderTraversalArray(this.root, array, 0);
		
//		for (T item : array) {
//			
//			System.out.print(item + " ");
//		}
		
		this.root = this.sortedArray2BST(array, 0, array.length - 1);
	}
	
	protected Integer inOrderTraversalArray(BSTNode<T> node, T[] array, int index) {
		
		if (node != null) {
			
			// We have to be able to update index, otherwise each frame will use
			// index = 0.
			index = inOrderTraversalArray(node.getLeft(), array, index);
			//queue.add(node.getData());
			array[index++] = node.getData();
			inOrderTraversalArray(node.getRight(), array, index);
		}
		
		// Update index.
		return index;
	}
	
	protected BSTNode<T> sortedArray2BST(T[] array, int lower, int upper) { 
		
		// Base case, which means we have traversed to the end.
		if (lower > upper) {
			
			 return null;
		}
   
	    int mid = (lower + upper) / 2;
	    BSTNode<T> node = new BSTNode<T>(array[mid], null, null);
	    node.setLeft(sortedArray2BST(array, lower, mid - 1));
	    node.setRight(sortedArray2BST(array, mid + 1, upper));
	    return node;
	}
	
	@SuppressWarnings("unchecked")
	public void balance(BSTNode<T> node) {
		
		T[] array = (T[]) new Comparable[this.size()];
		
		// Gets the array.
		this.inOrderTraversalArray(this.root, array, 0);
		
		// Removes the scapegoat from the array.
		for (T item : array) {
			
			if (item.equals(node)) {
				
				item = null;
			}
		}
	
		this.root = node = this.sortedArray2BST(array, 0, array.length - 1);
	}

	@Override
	public BSTNode<T> getRoot() {
        // DO NOT MODIFY
		return root;
	}

	public static <T extends Comparable<T>> String toDotFormat(BSTNode<T> root) {
		// header
		int count = 0;
		String dot = "digraph G { \n";
		dot += "graph [ordering=\"out\"]; \n";
		// iterative traversal
		Queue<BSTNode<T>> queue = new LinkedList<BSTNode<T>>();
		queue.add(root);
		BSTNode<T> cursor;
		while (!queue.isEmpty()) {
			cursor = queue.remove();
			if (cursor.getLeft() != null) {
				// add edge from cursor to left child
				dot += cursor.getData().toString() + " -> "
						+ cursor.getLeft().getData().toString() + ";\n";
				queue.add(cursor.getLeft());
			} else {
				// add dummy node
				dot += "node" + count + " [shape=point];\n";
				dot += cursor.getData().toString() + " -> " + "node" + count
						+ ";\n";
				count++;
			}
			if (cursor.getRight() != null) {
				// add edge from cursor to right child
				dot += cursor.getData().toString() + " -> "
						+ cursor.getRight().getData().toString() + ";\n";
				queue.add(cursor.getRight());
			} else {
				// add dummy node
				dot += "node" + count + " [shape=point];\n";
				dot += cursor.getData().toString() + " -> " + "node" + count
						+ ";\n";
				count++;
			}

		}
		dot += "};";
		return dot;
	}

	public static void main(String[] args) {
//		for (String r : new String[] { "a", "b", "c", "d", "e", "f", "g" }) {
//			BSTInterface<String> tree = new BinarySearchTree<String>();
//			for (String s : new String[] { "d", "b", "a", "c", "f", "e", "g" }) {
//				tree.add(s);
//			}
//			Iterator<String> iterator = tree.inorderIterator();
//			while (iterator.hasNext()) {
//				System.out.print(iterator.next());
//			}
//			System.out.println();
//			iterator = tree.preorderIterator();
//			while (iterator.hasNext()) {
//				System.out.print(iterator.next());
//			}
//			System.out.println();
//			iterator = tree.postorderIterator();
//			while (iterator.hasNext()) {
//				System.out.print(iterator.next());
//			}
//			System.out.println();
//
//			System.out.println(tree.remove(r));
//
//			iterator = tree.inorderIterator();
//			while (iterator.hasNext()) {
//				System.out.print(iterator.next());
//			}
//			System.out.println();
//		}

		BSTInterface<String> tree = new BinarySearchTree<String>();
		for (String r : new String[] { "a", "b", "c", "d", "e" }) {
			tree.add(r);
		}
		System.out.println(tree.size());
		System.out.println(tree.height());
		System.out.println(tree.isBalanced());
		tree.balance();
		
		
		//tree.balance(tree.getNode("b", tree.getRoot()));
		
		// Finds the middle node to balance, which is d.
//		System.out.println(tree.getRoot().getData());
//		System.out.println(tree.getRoot().getLeft().getData());
//		System.out.println(tree.getRoot().getRight().getRight().getData());
		
//		System.out.println(tree.size());
//		System.out.println(tree.height());
//		System.out.println(tree.isBalanced());
		
//		tree.balance(tree.getNode("b", tree.getRoot()));
//		
//		System.out.println(tree.getRoot().getData());
//		System.out.println(tree.getRoot().getLeft().getData());
//		System.out.println(tree.getRoot().getRight().getData());
//		System.out.println(tree.getRoot().getLeft().getRight().getData());
//		System.out.println(tree.getRoot().getRight().getRight().getData());
	}
}