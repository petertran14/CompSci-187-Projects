package structures;

import java.util.LinkedList;
import java.util.Queue;

public class Driver {

	public static void add(int[] array) {
		
		array[1] = 2;
	}
	
	public static void main(String[] args) {
		
//		int[] array = new int[2];
//		
//		array[0] = 1;
//		
//		Driver.add(array);
//		
//		for (int item : array) {
//			
//			System.out.println(item);
//		}
		
//		Queue<Integer> queue = new LinkedList<>();
//		queue.add(0);
//		queue.add(1);
//		queue.add(2);
//		
//		Object[] num =  queue.toArray();
//		
//		System.out.println(num[2]);
//		System.out.println(num[0].equals(queue.remove()));
		
		double d = Math.log(5) / Math.log(3.0/2.0);
		

		System.out.println(null == null);
		
		
	
		
	}
}
