package structures;

import java.util.Iterator;

/**
 * 
 * 
 * keep track of N (# of nodes), h (height), and q (upper bound).
   
• At insertion, q increments for each new node.
 
• At deletion, q remains unchanged.
Rule 1
• After inserting a new node, check the height condition. If violated, find scapegoat and rebuild the subtree rooted at the scapegoat
• After deleting a node, check the upper bound condition, if violated, rebuild the entire tree and reset q to N


 Suppose n is the number of nodes, h is the height of the tree, and q is the upperBound. 
 Then, the scapegoat tree is required to satisfy the following rules at all times:
	
	q/2≤n≤q , h≤log3/2(q)
 */

public class ScapegoatTree<T extends Comparable<T>> extends
		BinarySearchTree<T> {
	private int upperBound;
	
	public int getUpperBound() {
		
		return this.upperBound;
	}

	@Override
	public void add(T t) {
		// TODO
		
		// Insert.
		if (t == null) {
			throw new NullPointerException();
		}
		
		root = addToSubtree(root, new BSTNode<>(t, null, null));
		
		// Increment q for each new node.
		//System.out.println("Incrementing upperbound");
		this.upperBound++;
		
		this.heightCondition(t);	
	}
	
	private void heightCondition(T t) {
		
		// Check height condition h ≤ log3/2(q). Change of Base Formula.
		if (this.height() > (Math.log10(this.upperBound) / Math.log10(3.0 / 2.0))) {
			
			// Condition 1 is not satisfied, find a scapegoat. Traverses to where t was just inserted.
			BSTNode<T> scapegoat = this.getNode(t, this.getRoot());
			
			// The just added node cannot be the scapegoat since it has no children. Bottom of the tree.
			scapegoat = scapegoat.getParent();
			
			boolean found = false;
			
			// Iterate up the current node until we find the scapegoat.
			while (scapegoat != null && !found) {
				
				double leftChildSize = this.subtreeSize(scapegoat.getLeft());
				double rightChildSize = this.subtreeSize(scapegoat.getRight());
				double wSize = this.subtreeSize(scapegoat);
				
				// Check the node, such that the (size of its child nodes) / (size of the current node) > 2/3
				if (((leftChildSize + rightChildSize) / wSize) > 2.0/3.0) {
					
					found = true;
				}
				
				else {
					
					// Traverse up the tree.
					scapegoat = scapegoat.getParent();
				}
			}
			
			// Get the parent node of the scapegoat.
			BSTNode<T> parent = scapegoat.getParent();
			
			// Create a new tree, and balance the tree.
			BSTInterface<T> newTree = new BinarySearchTree<T>();
			
			// Set up an iterator, rooted at the scapegoat.
			Iterator<T> iterator = inorderIterator(scapegoat);
			
			// Populate the newTree from the scapegoat.
			while (iterator.hasNext()) {
				
				newTree.add(iterator.next());
			}
			
			// Balance the subtree.
			newTree.balance();
			
			// Get the root of the balanced tree.
			BSTNode<T> rootOfBalancedTree = newTree.getRoot();
			
			// Follow the ordering property of a BST.
			
			// If the root of the tree is greater than the parent, then the root is the left child of the parent.
			if (rootOfBalancedTree.getData().compareTo(parent.getData()) <= 0) {
				
				parent.setLeft(rootOfBalancedTree);
				rootOfBalancedTree.setParent(parent);
			}
			
			// If the root of the tree is less than the parent, then the root is the right child of the parent.
			if (rootOfBalancedTree.getData().compareTo(parent.getData()) > 0) {
				
				parent.setRight(rootOfBalancedTree);
				rootOfBalancedTree.setParent(parent);
			}
		}
	}

	@Override
	public boolean remove(T element) {
		// TODO
		
		if (element == null) {
			
			throw new NullPointerException();
		}
		
		boolean removed = super.remove(element);
		
		this.upperBoundCondition(removed);
		
		return removed;
	}
	
	private void upperBoundCondition(boolean removed) {
		
		int size = this.size();
		
		// Check upper bound condition q/2 ≤ n ≤ q. Also, only do this if the remove
		// was successful.
		//if (this.upperBound > (2 * this.size()) && removed) {
		if (this.upperBound > (2 * size) && removed) {
//		
//			// If violated, rebuild the entire tree.
//			// Create a new tree, and balance the tree.
//			BSTInterface<T> newTree = new BinarySearchTree<T>();
//			
//			// Set up an iterator at the root.
//			Iterator<T> iterator = this.inorderIterator();
//			
//			// Populate the newTree from the scapegoat.
//			while (iterator.hasNext()) {
//				
//				newTree.add(iterator.next());
//			}
//			
//			// Balance the subtree.
//			newTree.balance();
			
			this.balance();
			
			// Set upperbound equal to the size of the tree.
			this.upperBound = size;
		}
	}
}
