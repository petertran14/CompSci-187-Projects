package structures;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.junit.Rule;
import org.junit.Test;
import org.junit.Before;
import org.junit.rules.Timeout;

public class PublicBinarySearchTreeTest {

	private BSTInterface<Integer> emptyTree;
	private BSTInterface<String> oneNodeTree;
	private BSTInterface<String> multiNodeTree;
	private static final String FOO = "foo";
	private static final String APPLE = "apple";
	private static final String PEACH = "peach";
	private static final String KIWI = "kiwi";
	private static final String MANGO = "mango";

	//@Rule
    //public Timeout timeout = new Timeout(1L, TimeUnit.SECONDS);
	
	@Before
	public void before() {
		emptyTree = new BinarySearchTree<Integer>();
		oneNodeTree = new BinarySearchTree<String>();
		multiNodeTree = new BinarySearchTree<String>();
		oneNodeTree.add(FOO);
		
		multiNodeTree.add(FOO);
		multiNodeTree.add(APPLE);
		multiNodeTree.add(PEACH);
		multiNodeTree.add(KIWI);
	}
	
	@Test
	public void testEmpty() {
		assertTrue(emptyTree.isEmpty());
	}

	@Test
	public void testNotEmpty() {
		assertFalse(oneNodeTree.isEmpty());
	}

	@Test
	public void testSize() {
		assertEquals(0, emptyTree.size());
		assertEquals(1, oneNodeTree.size());
	}
	
	@Test
	public void testContains() {
		assertTrue(oneNodeTree.contains(FOO));
	}
	
	@Test
    public void testRemove() {
		assertFalse(emptyTree.remove(0));
	}
	
	@Test
	public void testGet() {
		assertEquals(FOO, multiNodeTree.get(FOO));
		assertEquals(APPLE, multiNodeTree.get(APPLE));
		assertEquals(PEACH, multiNodeTree.get(PEACH));
		assertEquals(KIWI, multiNodeTree.get(KIWI));
		assertEquals(null, multiNodeTree.get(MANGO));
	}
	
	@Test
	public void testAdd() {
		emptyTree.add(1);
		assertFalse(emptyTree.isEmpty());
		assertEquals(1, emptyTree.size());
	}
	
	@Test
	public void testGetMinimum() {
		assertEquals(null, emptyTree.getMinimum());
	}
	
	@Test 
	public void testGetMinimumComplex() {
		
		assertEquals(APPLE, multiNodeTree.getMinimum());
	}

	@Test
	public void testGetMaximum() {
		assertEquals(FOO, oneNodeTree.getMaximum());
	}
	
	@Test
	public void testGetMaximumComplex() {
		
		assertEquals(PEACH, multiNodeTree.getMaximum());
	}

	@Test
	public void testHeight() {
		assertEquals(-1, emptyTree.height());
		assertEquals(0, oneNodeTree.height());
	}
	
	@Test
	public void testHeightComplex() {
		
		assertEquals(2, multiNodeTree.height());
	}
	
	@Test
	public void testPreorderIterator() {
		Iterator<String> i = oneNodeTree.preorderIterator();
		while (i.hasNext()) {
			assertEquals(FOO, i.next());			
		}
	}

	@Test
	public void testInorderIterator() {
		Iterator<String> i = oneNodeTree.inorderIterator();
		while (i.hasNext()) {
			assertEquals(FOO, i.next());			
		}
	}

	@Test
	public void testPostorderIterator() {
		Iterator<Integer> i = emptyTree.postorderIterator();
		assertFalse(i.hasNext());
	}
	
	@Test
	public void testEquals() {
		BSTInterface<String> tree = new BinarySearchTree<String>();
		assertFalse(oneNodeTree.equals(tree));
		tree.add(new String("foo"));
		assertTrue(oneNodeTree.equals(tree));
	}
	
	@Test (expected = NullPointerException.class)
	public void testEqualsNullTree() {
		
		multiNodeTree.equals(null);
	}
	
	@Test
	public void testEqualsComplex() {
		
		BSTInterface<String> tree = new BinarySearchTree<String>();
		assertFalse(multiNodeTree.equals(tree));
		
		tree.add(FOO);
		tree.add(APPLE);
		tree.add(PEACH);
		
		assertFalse(multiNodeTree.equals(tree));
		
		tree.add(KIWI);
		
		assertTrue(multiNodeTree.equals(tree));
		
		tree.add(MANGO);
		
		assertFalse(multiNodeTree.equals(tree));
	}
	
	@Test
	public void testSameValues() {
		BSTInterface<Integer> tree = new BinarySearchTree<Integer>();
		assertTrue(emptyTree.sameValues(tree));
		
		emptyTree.add(1);
		emptyTree.add(2);
		
		tree.add(2);
		tree.add(1);
		
		assertTrue(emptyTree.sameValues(tree));
	}
	
	@Test (expected = NullPointerException.class)
	public void testSameValuesNullTree() {
		
		multiNodeTree.sameValues(null);
	}
	
	@Test
	public void testSameValuesComplex() {
		
		BSTInterface<String> tree = new BinarySearchTree<String>();
	
		assertFalse(multiNodeTree.sameValues(tree));
		
		tree.add(FOO);
		tree.add(APPLE);
		tree.add(PEACH);
		
		assertFalse(multiNodeTree.sameValues(tree));
		
		tree.add(KIWI);
		
		assertTrue(multiNodeTree.sameValues(tree));
		
		tree.add(MANGO);
		
		assertFalse(multiNodeTree.sameValues(tree));
	}
	
	@Test 
	public void testIsBalanced() {
		// disabled due to late change of isBalanced() specification
		// assertTrue(emptyTree.isBalanced());
		emptyTree.add(1);
		assertTrue(emptyTree.isBalanced());
		emptyTree.add(2);
		assertTrue(emptyTree.isBalanced());
		emptyTree.add(3);
		assertFalse(emptyTree.isBalanced());
	}
	
	@Test 
	public void testBalance() {
		emptyTree.add(1);
		emptyTree.add(2);
		emptyTree.add(3);
		assertFalse(emptyTree.isBalanced());
		
		emptyTree.balance();
		
		assertTrue(emptyTree.isBalanced());
	}
	
//	TestBalancedSeven- make a BST with values 7-1, then test the size, height, then test the data in the nodes are in 
//	the correct place in the tree.
	@Test
	public void testBalancedSeven() {
		
		BSTInterface<Integer> tree = new ScapegoatTree<>();
		
		int[] array = {7,6,5,4,3,2,1};
		
		for (Integer item : array) {
			
			tree.add(item);
		}
		
		Integer seven = 7;
		Integer six = 6;
		Integer five = 5;
		Integer four = 4;
		Integer three = 3;
		Integer two = 2;
		Integer one = 1;
		
		assertEquals(4, tree.height());
		assertEquals(7, tree.size());
		assertEquals(seven, tree.getRoot().getData());
		assertEquals(four, tree.getRoot().getLeft().getData());
		assertEquals(three, tree.getRoot().getLeft().getLeft().getData());
		assertEquals(five, tree.getRoot().getLeft().getRight().getData());
		assertEquals(two, tree.getRoot().getLeft().getLeft().getLeft().getData());
		assertEquals(one, tree.getRoot().getLeft().getLeft().getLeft().getLeft().getData());
		assertEquals(six, tree.getRoot().getLeft().getRight().getRight().getData());
	}
	
	@Test
	public void testEqualsTwoEmptyTree() {
		
		BSTInterface<Integer> emptyTree1 = new BinarySearchTree<>();
		BSTInterface<Integer> emptyTree2 = new BinarySearchTree<>();
		
		assertTrue(emptyTree1.equals(emptyTree2));
	}
	
	@Test
	public void testNotEqualsStructure() {
		
		BSTInterface<Integer> tree1 = new BinarySearchTree<>();
		BSTInterface<Integer> tree2 = new BinarySearchTree<>();
		
		tree1.add(1);
		tree1.add(2);
		tree1.add(3);
		
		tree2.add(2);
		tree2.add(1);
		tree2.add(3);
		
		assertFalse(tree1.equals(tree2));
	}
}
