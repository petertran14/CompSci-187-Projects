package structures;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.Rule;
import org.junit.Test;
import org.junit.Before;
import org.junit.rules.Timeout;

public class PublicScapegoatTreeTest {

	private BSTInterface<Integer> tree;
	private BSTInterface<String> stringTree;

	//@Rule
  //  public Timeout timeout = new Timeout(1L, TimeUnit.SECONDS);
	
	@Before
	public void before() {
		tree = new ScapegoatTree<Integer>();
		stringTree = new BinarySearchTree<String>();
		
	}
	
	@Test
	public void testAdd() {
		tree.add(0);
		tree.add(1);
		tree.add(2);
		tree.add(3);
		assertEquals(3, tree.height());
		tree.add(4);
		assertEquals(3, tree.height());
	}
	
	@Test 
	public void testRemove() {
		for (int i: new int[] {3, 1, 5, 0, 4, 2, 6} ) {
			tree.add(i);
		}

		for (int i: new int[] {1, 2, 0, 4}) {
			tree.remove(i);
		}
		
		BSTInterface<Integer> smallTree = new BinarySearchTree<Integer>();
		smallTree.add(5);
		smallTree.add(3);
		smallTree.add(6);
		
		assertTrue(tree.equals(smallTree));
		assertEquals(3, tree.size());
	}
	
	@Test
	public void testRemoveFalse() {
		
		for (Integer item : new int[] { 1, 2, 3, 4}) {
			
			tree.add(item);
		}
		
		for (int item : new int[] {5, 6, 7, 8}) {
			
			tree.remove(item);
		}
		
		BSTInterface<Integer> smallTree = new BinarySearchTree<Integer>();
		smallTree.add(1);
		smallTree.add(2);
		smallTree.add(3);
		smallTree.add(4);
		
		assertEquals(4, tree.size());
		assertTrue(tree.equals(smallTree));
		assertFalse(tree.remove(100));
		assertTrue(tree.remove(1));
	}
	
	@Test
	public void testRemoveOnlyNode() {
		
		tree.add(1);
		tree.remove(1);
		//tree.balance();

		//System.out.println(tree.isEmpty());
		
		BSTInterface<Integer> smallTree = new BinarySearchTree<Integer>();
		//System.out.println(tree.getRoot());
		//System.out.println(smallTree.getRoot());
		assertTrue(tree.equals(smallTree));
	}
	
	@Test
	public void testRemoveRootNode() {
		
		int[] array = new int[] { 1, 2, 3, 4, 5};
		
		for (Integer item : array) {
			
			tree.add(item);
		}
		
		Integer one = 1;
		Integer two = 2;
		Integer three = 3;
		Integer four = 4;
		Integer five = 5;
		
		assertEquals(one, tree.getRoot().getData());
		assertEquals(three, tree.getRoot().getRight().getData());
		assertEquals(two, tree.getRoot().getRight().getLeft().getData());
		assertEquals(four, tree.getRoot().getRight().getRight().getData());
		assertEquals(five, tree.getRoot().getRight().getRight().getRight().getData());
		
		
		System.out.println("\nStarting Here: ");
		tree.remove(1);
		tree.remove(2);
		tree.remove(3);
		assertEquals(four, tree.getRoot().getData());
	}
}
