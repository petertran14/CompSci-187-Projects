package structures;

import java.util.NoSuchElementException;

import filesystem.LevelOrderIterator;

/**************************************************************************************
 * NOTE: before starting to code, check support/structures/UnboundedQueueInterface.java
 * for detailed explanation of each interface method, including the parameters, return
 * values, assumptions, and requirements
 ***************************************************************************************/
public class Queue<T> implements UnboundedQueueInterface<T> {
	
	private Node<T> head;
	private Node<T> tail;
	private int size;

	public Queue() {		
		
		this.head = new Node<T>(null);
		this.tail = this.head;
		this.size = 0;
    }
	
	public Queue(Queue<T> other) {
		
		if (other.isEmpty()) {
			
			this.head = new Node<T>(null);
			this.tail = this.head;
			this.size = 0;
		}
		
		else {
			
			Node<T> temp = other.head;
			
			while (temp != null) {
				
				this.enqueue(temp.data);
				temp = temp.next;
			}
		}
	}
	
	@Override
	public boolean isEmpty() {

		return this.size == 0;
	}

	@Override
	public int size() {
		
		return this.size;
	}

	@Override
	public void enqueue(T element) {
         
		// If the queue is initially empty, then the head and tail point to the same node.
		if (this.isEmpty()) {
			
			this.head = new Node<T>(element);
			this.tail = this.head;
		}
		
		// The queue has at least 1 element. Create a new node after tail and reassign tail.
		else {
			
			this.tail.next = new Node<T>(element);
			this.tail = this.tail.next;
		}
		
		// Regardless, increment size.
		this.size++;
	}

	@Override
	public T dequeue() throws NoSuchElementException {
           
		// If the queue is empty, then the user is notified of an error.
		if (this.isEmpty()) {
			
			throw new NoSuchElementException();
		}
		
		// Get the data in head before the node is disconnected.
		T data = this.head.data;
		
		// Temp pointer to delete head node.
		Node<T> garbage = this.head;
		
		// Update head.
		this.head = this.head.next;
		
		// Old head no longer is part of the linked list.
		garbage.next = null;
		
		// Nothing points to the old head, so it can get deleted.
		garbage = null;
		
		this.size--;
		
		return data;
	}

	@Override
	public T peek() throws NoSuchElementException {
       
		if (this.isEmpty()) {
			
			throw new NoSuchElementException();
		}
		
		return this.head.data;
	}

	
	@Override
	public UnboundedQueueInterface<T> reversed() {
            
		// If the queue is empty, then return the object of the class using a copy constructor.
		if (this.isEmpty()) {
			
			return new Queue<T>(this);
		}
		
		// Using the copy constructor to make an alias of our queue, but not change the original.
		Queue<T> myQueue = new Queue<T>(this);
		Queue<T> reverse = new Queue<T>();
		
		while (!myQueue.isEmpty()) {
			
			reverse.pushFront(myQueue.dequeue());
		}
		
		return new Queue<T>(reverse);
	}
	
	/**
	 * Pushes an element to the head of the queue.
	 * 
	 * Needed to reverse a queue.
	 * 
	 * @param element
	 */
	public void pushFront(T element) {
		
		if (this.isEmpty()) {
			
			this.head = new Node<T>(element);
			this.tail = this.head;
		}
		
		else {
			
			Node<T> node = new Node<T>(element, this.head);
			this.head = node;
		}
		
		this.size++;
	}
}

class Node<T> {
	public T data;
	public Node<T> next;
	public Node(T data) { this.data=data;}
	public Node(T data, Node<T> next) {
		this.data = data; this.next=next;
	}
}

