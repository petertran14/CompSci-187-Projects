package filesystem;

import java.io.File;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.NoSuchElementException;

import structures.Queue;

/*
 * A directory is a path from a root the goal target of the hierarchy.
 * A file is a singular entity, that may or may not exist at the end of a directory path.
 */

/*
What to do. For full credit, correctly implement next() and hasNext() in LevelOrderIterator.java. 
Your code should systematically iterate through the nodes in a filesystem tree, rooted at a given node. 
First, it should visit the root node. Then, it should visit each of that node’s children 
(that is, each node directly connected to the root node). Then it should visit each of those node’s children, and so on. 
This approach will visit the root node, then all of the nodes one level below it, then all of the nodes one level below those nodes. 
This is called a level-order traversal. In essence, your code will perform a so called breadth-first search (BFS) of a 
given tree within the filesystem.

Java represents filesystem nodes using class java.io.File. 
You’ll want to skim through the API documentation for File. 
Pay attention to the constructor and the exists(), isDirectory(), and listFiles() methods.

To ensure you traverse the tree in level order, your code will need to visit the nodes in first-in-first-out order, 
adding children of the current node to a queue of nodes waiting to be visited in order. 
(Use the Queue you created in Problem 1; DO NOT use java.util.Queue.) When you obtain the children of a node, 
sort them in lexicographic before enqueueing them. The sorting can be done using Java’s Arrays.sort method. 
The File class already defines a compareTo method, which Arrays.sort relies on.
*/


/**
 * An iterator to perform a level order traversal of part of a 
 * filesystem. A level-order traversal is equivalent to a breadth-
 * first search.
 */
public class LevelOrderIterator extends FileIterator<File> {
	
	// Hold the File Nodes that will be visited. Also this is lexicographically sorted.
	private Queue<File> visited;
	Queue<File> frontier;
	
	// Keeps track of the current file "node".
	private File currentFile;
	
	/**
	 * Instantiate a new LevelOrderIterator, rooted at the rootNode.
	 * 
	 * This is a constructor.
	 * 
	 * @param rootNode
	 * @throws FileNotFoundException if the rootNode does not exist
	 */
	public LevelOrderIterator(File rootNode) throws FileNotFoundException {
        
		// We are given a file or directory whose "pathname" does not exist
		if (!rootNode.exists()) {
			
			throw new FileNotFoundException();
		}
		
		this.visited = new Queue<File>();
		this.frontier = new Queue<File>();
		
		// We consider the rootNode file to be the first file visited.
		visited.enqueue(rootNode);
		frontier.enqueue(rootNode);
		
		// CurrentFile holds the current node of the hierarchy.
		this.currentFile = rootNode;
	}
	
	@Override
	public boolean hasNext() {
		
		return !this.frontier.isEmpty();
	}

	/**
	 * This method checks to see if there is another element after the current node. So maybe it should enqueue only
	 * one node/file at a time.
	 */
	@Override
	public File next() throws NoSuchElementException {
		
		if (this.frontier.isEmpty()) {
			
			throw new NoSuchElementException();
		}
        	
		// First time: Gives us the list of child files that are associated with the root file.
		// Subsequent times: Gives us the list of child files of the current frontier file.
		this.currentFile = this.frontier.peek();
		
		// If there are no children, then listFiles() returns null.
		File[] childrenFiles = this.frontier.dequeue().listFiles();
		
		// Modifies the array in place.
		if (childrenFiles != null) {
			
			Arrays.sort(childrenFiles, null);
		
			// Iterate through each child file.
			for (int i = 0; i < childrenFiles.length; i++) {
				
				this.frontier.enqueue(childrenFiles[i]);
				this.visited.enqueue(childrenFiles[i]);
			}
		}
		
		return this.currentFile;
	}

	@Override
	public void remove() {
		// Leave this one alone.
		throw new UnsupportedOperationException();		
	}

	/*
	 * 
public File(String pathname)
Creates a new File instance by converting the given pathname string into an abstract pathname. If the given string is the empty string, then the result is the empty abstract pathname.
Parameters:
pathname - A pathname string
Throws:
NullPointerException - If the pathname argument is null

public boolean exists()
Tests whether the file or directory denoted by this abstract pathname exists.
Returns:
true if and only if the file or directory denoted by this abstract pathname exists; false otherwise

public boolean isDirectory()
Tests whether the file denoted by this abstract pathname is a directory.
Where it is required to distinguish an I/O exception from the case that the file is not a directory, or 
where several attributes of the same file are required at the same time, then the Files.readAttributes method may be used.
Returns:
true if and only if the file denoted by this abstract pathname exists and is a directory; false otherwise

public File[] listFiles()
Returns an array of abstract pathnames denoting the files in the directory denoted by this abstract pathname.
If this abstract pathname does not denote a directory, then this method returns null. 
Otherwise an array of File objects is returned, one for each file or directory in the directory. 
Pathnames denoting the directory itself and the directory's parent directory are not included in the result. 
Each resulting abstract pathname is constructed from this abstract pathname using the File(File, String) constructor. 
Therefore if this pathname is absolute then each resulting pathname is absolute; if this pathname is relative then each 
resulting pathname will be relative to the same directory.

There is no guarantee that the name strings in the resulting array will appear in any specific order; they are not, 
in particular, guaranteed to appear in alphabetical order.

Note that the Files class defines the newDirectoryStream method to open a directory and iterate over the names 
of the files in the directory. This may use less resources when working with very large directories.

Returns:
An array of abstract pathnames denoting the files and directories in the directory denoted by this abstract pathname. 
The array will be empty if the directory is empty. Returns null if this abstract pathname does not denote a directory, 
or if an I/O error occurs.

	 */
}
