package fizzbuzz;

public class Driver {

	public static void main(String[] args) {
		
		int num = 492795;
		
		while (num != 0) {
			
			System.out.println(num % 10);
			num = num / 10;
		}
		
		int[] array = new int[5];
	}
}
