package stack;

/**
 * A {@link LinkedStack} is a generic stack that is implemented using
 * a Linked List structure to allow for unbounded size.
 * 
 * This is a top-down reference stack.
 */
public class LinkedStack<T> {
	
	private LLNode<T> top;
	private int size;
	
	public LinkedStack() {
		
		this.top = null;
		this.size = 0;
	}

	/**
	 * Remove and return the top element on this stack.
	 * If stack is empty, return null (instead of throw exception)
	 */
	public T pop() {
		
		T data = null;
		
		// The stack is empty.
		if (this.isEmpty()) {
			
			return null;
		}
		
		else {
			
			data = top.info;
			LLNode<T> garbage = this.top;
			this.top = this.top.link;
			garbage.link = null;
		}
		
		this.size--;
		
		return data;
	}

	/**
	 * Return the top element of this stack (do not remove the top element).
	 * If stack is empty, return null (instead of throw exception)
	 */
	public T top() {
		
		if (this.isEmpty()) {
			
			return null;
		}
		
		return this.top.info;
	}

	/**
	 * Return true if the stack is empty and false otherwise.
	 */
	public boolean isEmpty() {
		
		return this.size == 0;
	}

	/**
	 * Return the number of elements in this stack.
	 */
	public int size() {
		
		return this.size;
	}

	/**
	 * Pushes a new element to the top of this stack.
	 * 
	 * Implementation where the top node has references down the stack.
	 * 
	 * I could have done it where the bottom node has reference up the stack, but
	 * then for the pop method I would have to traverse to one behind the top stack.
	 */
	public void push(T elem) {
		
		// The stack is empty.
		if (this.isEmpty()) {
			
			this.top = new LLNode<T>(elem);
		}
		
		// The stack is not empty.
		else {
			
			// A new temp node that holds the elem.
			LLNode<T> temp = new LLNode<T>(elem);
			
			// the temp node points to the top.
			temp.link = top;
			
			// The top now points to temp.
			top = temp;
		}
		
		// increment size.
		this.size++;
	}

}
