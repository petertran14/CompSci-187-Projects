package evaluator;

import parser.ArithParser;

public class Driver {
	
	public static int factorial(int num) {
		
		if (num == 0) {
			
			return 1;
		}
		
		return num * factorial(num - 1);
	}

	public static void main(String[] args) {
		
		Integer a = 5;
		
		//System.out.println(a > null);
	}
}
