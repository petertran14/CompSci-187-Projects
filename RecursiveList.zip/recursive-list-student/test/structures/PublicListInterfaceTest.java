package structures;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PublicListInterfaceTest {

	private ListInterface<String> list;

	@Before
	public void setup(){
          list = new RecursiveList<String>();
	}

	@Test (timeout = 500)
	public void testInsertFirstIsEmptySizeAndGetFirst1() {
		assertTrue("Newly constructed list should be empty.", list.isEmpty());
		assertEquals("Newly constructed list should be size 0.", 0, list.size());
		assertEquals("Insert First should return instance of self", list, list.insertFirst("hello"));
		assertFalse("List should now have elements.", list.isEmpty());
		assertEquals("List should now have 1 element.", 1, list.size());
		assertEquals("First element should .equals \"hello\".", "hello", list.getFirst());
		list.insertFirst("world");
		assertEquals(2, list.size());
		list.insertFirst("foo");
		assertEquals(3, list.size());
		assertEquals("First element should .equals \"foo\".", "foo", list.getFirst());
	}
	
	@Test 
	public void testInsertFirst() {
		
		list.insertFirst("first");
		list.insertFirst("second");
		list.insertFirst("third");
		
		assertEquals(2, list.indexOf("first"));
		assertEquals(1, list.indexOf("second"));
		assertEquals(0, list.indexOf("third"));
		assertEquals(3, list.size());
		
		assertEquals("third", list.getFirst());
		assertEquals("first", list.getLast());
	}
	
	@Test 
	public void testIndexOfNotFound() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		assertEquals(-1, list.indexOf("millionth"));
	}
	
	@Test
	public void testIndexOf() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		assertEquals(0, list.indexOf("first"));
		assertEquals(1, list.indexOf("second"));
		assertEquals(2, list.indexOf("third"));
		
		assertEquals("first", list.getFirst());
		assertEquals("third", list.getLast());
	}
	
	@Test (expected = NullPointerException.class)
	public void testInsertAtNullElement() {
		
		list.insertAt(0, null);
	}
	
	@Test (expected = IndexOutOfBoundsException.class) 
	public void testInsertAtAboveBounds() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		list.insertAt(5, "fuji");
	}
	
	@Test (expected = IndexOutOfBoundsException.class) 
	public void testInsertAtBelowBounds() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		list.insertAt(-1, "fuji");
	}
	
	@Test
	public void testInsertAtBeginning() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		list.insertAt(0, "fuji");
		
		assertEquals(0, list.indexOf("fuji"));
		assertEquals(1, list.indexOf("first"));
		assertEquals(2, list.indexOf("second"));
		assertEquals(3, list.indexOf("third"));
		assertEquals(4, list.size());
		
		assertEquals("fuji", list.getFirst());
		assertEquals("third", list.getLast());
	}
	
	@Test
	public void testInsertAtMiddle() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		list.insertAt(1, "fuji");
		list.insertAt(2, "mango");
		
		assertEquals(0, list.indexOf("first"));
		assertEquals(1, list.indexOf("fuji"));
		assertEquals(2, list.indexOf("mango"));
		assertEquals(3, list.indexOf("second"));
		assertEquals(4, list.indexOf("third"));
		assertEquals(5, list.size());
		
		assertEquals("first", list.getFirst());
		assertEquals("third", list.getLast());
	}
	
	@Test
	public void testInsertAtEnd() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		list.insertAt(2, "fuji");
		
		assertEquals(0, list.indexOf("first"));
		assertEquals(1, list.indexOf("second"));
		assertEquals(2, list.indexOf("fuji"));
		assertEquals(3, list.indexOf("third"));
		assertEquals(4, list.size());
		
		assertEquals("first", list.getFirst());
		assertEquals("third", list.getLast());
	}
	
	@Test
	public void testRemoveFirst() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		assertEquals("first", list.removeFirst());
		
		assertEquals("second", list.getFirst());
		assertEquals("third", list.getLast());
		
		assertEquals("second", list.removeFirst());
		
		assertEquals("third", list.getFirst());
		assertEquals("third", list.getLast());
		
		assertEquals("third", list.removeFirst());
		assertEquals(0, list.size());
	}
	
	@Test (expected = IllegalStateException.class)
	public void testRemoveFirstEmpty() {
		
		list.removeFirst();
	}
	
	@Test
	public void testRemoveLast() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		assertEquals("third", list.removeLast());
		
		assertEquals("first", list.getFirst());
		assertEquals("second", list.getLast());
		
		assertEquals("second", list.removeLast());
		
		assertEquals("first", list.getFirst());
		assertEquals("first", list.getLast());
		
		assertEquals("first", list.removeLast());
		assertEquals(0, list.size());
	}
	
	@Test (expected = IllegalStateException.class)
	public void testRemoveLastEmpty() {
		
		list.removeLast();
	}
	
	@Test
	public void testRemoveAtBeginning() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		assertEquals("first", list.removeAt(0));
		assertEquals("second", list.getFirst());
		assertEquals("third", list.getLast());
		assertEquals(2, list.size());
	}
	
	@Test
	public void testRemoveAtEnd() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		assertEquals("third", list.removeAt(2));
		assertEquals("first", list.getFirst());
		assertEquals("second", list.getLast());
		assertEquals(2, list.size());
	}
	
	@Test
	public void testRemoveAtMiddle() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		assertEquals("second", list.removeAt(1));
		assertEquals("first", list.getFirst());
		assertEquals("third", list.getLast());
		assertEquals(2, list.size());
	}
	
	@Test (expected = IndexOutOfBoundsException.class)
	public void testRemoveAtAboveBounds() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		list.removeAt(4);
	}
	
	@Test (expected = IndexOutOfBoundsException.class)
	public void testRemoveAtBelowBounds() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		list.removeAt(-1);
	}
	
	@Test
	public void testGet() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		assertEquals("first", list.get(0));
		assertEquals("second", list.get(1));
		assertEquals("third", list.get(2));
		
		assertEquals(3, list.size());
	}

	@Test (expected = IndexOutOfBoundsException.class)
	public void testGetAboveBounds() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		list.get(4);
	}
	
	@Test (expected = IndexOutOfBoundsException.class)
	public void testGetBelowBounds() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		list.get(-1);
	}
	
	@Test
	public void testRemove() {
		
		list.insertLast("first");
		list.insertLast("second");
		list.insertLast("third");
		
		assertEquals(true, list.remove("first"));
		
		assertEquals("second", list.getFirst());
		assertEquals("third", list.getLast());
		assertEquals(2, list.size());
		
		assertEquals(true, list.remove("second"));
		
		assertEquals("third", list.getFirst());
		assertEquals("third", list.getLast());
		assertEquals(1, list.size());
		
		assertEquals(true, list.remove("third"));
		assertEquals(0, list.size());
		
		assertEquals(false, list.remove("fourth"));
	}
	
	@Test
	public void testInsertLastRemoveLastSizeAndIsEmpty() {
		
		list.insertLast("last");
		assertEquals("last", list.removeLast());
		assertEquals(0, list.size());
		assertTrue(list.isEmpty());
	}
	
	@Test
	public void testInsertsRemoveAndIndexOf1() {
		
		list.insertLast("third");
		list.insertLast("fourth");
		list.insertLast("fifth");
		
		list.insertFirst("second");
		list.insertFirst("first");
		list.insertFirst("zero");
		
		assertEquals("zero", list.get(0));
		assertEquals("first", list.get(1));
		assertEquals("second", list.get(2));
		assertEquals("third", list.get(3));
		assertEquals("fourth", list.get(4));
		assertEquals("fifth", list.get(5));
		
		list.removeAt(0);
		list.removeAt(4);
		
		list.removeAt(1);
		list.removeAt(1);
		
		assertEquals(0, list.indexOf("first"));
		assertEquals(1, list.indexOf("fourth"));
	}
	
	@Test
	public void testInsertsRemoveAndIndexOf2() {
		
		list.insertLast("third");
		list.insertLast("fourth");
		list.insertLast("fifth");
		
		list.insertFirst("second");
		list.insertFirst("first");
		list.insertFirst("zero");
		
		assertTrue(list.remove("zero"));
		assertTrue(list.remove("fifth"));
		
		assertEquals(0, list.indexOf("first"));
		assertEquals(1, list.indexOf("second"));
		assertEquals(2, list.indexOf("third"));
		assertEquals(3, list.indexOf("fourth"));
		
		assertTrue(list.remove("second"));
		assertTrue(list.remove("third"));
		
		assertEquals(0, list.indexOf("first"));
		assertEquals(1, list.indexOf("fourth"));
	}
	
	@Test
	public void testInsertsRemoveAndIndexOf3() {
		
		list.insertLast("third");
		list.insertLast("fourth");
		list.insertLast("fifth");
		
		list.insertFirst("second");
		list.insertFirst("first");
		list.insertFirst("zero");
		
		assertEquals("zero", list.removeFirst());
		
		assertEquals(0, list.indexOf("first"));
		assertEquals(1, list.indexOf("second"));
		assertEquals(2, list.indexOf("third"));
		assertEquals(3, list.indexOf("fourth"));
		assertEquals(4, list.indexOf("fifth"));
		
		assertEquals("fifth", list.removeLast());
		
		assertEquals(0, list.indexOf("first"));
		assertEquals(1, list.indexOf("second"));
		assertEquals(2, list.indexOf("third"));
		assertEquals(3, list.indexOf("fourth"));
		
		assertEquals("first", list.removeFirst());
		
		assertEquals(0, list.indexOf("second"));
		assertEquals(1, list.indexOf("third"));
		assertEquals(2, list.indexOf("fourth"));
		
		assertEquals("fourth", list.removeLast());
		
		assertEquals(0, list.indexOf("second"));
		assertEquals(1, list.indexOf("third"));
		
		assertEquals("second", list.removeFirst());
		
		assertEquals(0, list.indexOf("third"));
		
		assertEquals("third", list.removeLast());
		
		assertTrue(list.isEmpty());
	}
	
	@Test
	public void testInsertsGetsRemovesSize() {
		
		assertTrue("Newly constructed list should be empty.", list.isEmpty());
        list.insertLast("Hello").insertLast("World!");
        assertEquals("Insert at should return an instance of the list.", list, list.insertAt(1, "There"));
        assertEquals("Size should be 3", 3, list.size());
        assertEquals("0th element should .equals \"Hello\"", "Hello", list.get(0));
        assertEquals("Last element should .equals \"World!\"", "World!", list.getLast());
        list.insertAt(0, "foo").insertAt(4, "bar");
        assertEquals("foo", list.get(0));
        assertEquals("bar", list.get(4));
        assertEquals("Size should be 5", 5, list.size());
        assertEquals("The third element should have been \"World!\"", "World!", list.removeAt(3));
        assertEquals("Size should be 4", 4, list.size());
        assertEquals("Last element should be \"bar\"", "bar", list.getLast());
	}
	
	@Test
	public void testInsertsRemoveAndIndexOf4() {
		
		list.insertLast("Hello").insertLast("World");
        assertEquals("Hello is at index 0", 0, list.indexOf("Hello"));
        assertEquals("World is at index 1", 1, list.indexOf("World"));
        assertEquals("Foo is not in the list.", -1, list.indexOf("Foo"));
        assertTrue("Hello can be removed.", list.remove("Hello"));
        assertEquals("Size should now be 1", 1, list.size());
        list.insertLast("Hello").insertLast("There").insertLast("Hello");
        assertEquals("World is at index 0", 0, list.indexOf("World"));
        assertEquals("First Hello is at index 1", 1, list.indexOf("Hello"));
        assertTrue("Hello can be removed.", list.remove("Hello"));
        assertEquals("First Hello is at index 2", 2, list.indexOf("Hello"));
        assertTrue("Hello can be removed.", list.remove("Hello"));
        assertEquals("Size of list should now be 2", 2, list.size());
        assertFalse("Foo cannot be removed.", list.remove("Foo"));
        assertEquals("Size of list should now be 2", 2, list.size());
        assertFalse("Hello cannot be removed.", list.remove("Hello"));
	}
}
