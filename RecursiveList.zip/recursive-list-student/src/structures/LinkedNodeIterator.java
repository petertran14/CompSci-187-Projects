package structures;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkedNodeIterator<T> implements Iterator<T> {
	
	private LLNode<T> current;
	
	public LinkedNodeIterator(LLNode<T> node) {
		
		this.current = node;
	}

	@Override
	public boolean hasNext() {
		
		return this.current != null;
	}

	@Override
	public T next() {
		
		if (this.current == null) {
			
			throw new NoSuchElementException();
		}
		
		T data = this.current.getData();
		this.current = this.current.getNext();
		return data;
	}

	@Override
	  public void remove() {
	    // Nothing to change for this method
	    throw new UnsupportedOperationException();
	  }
}
