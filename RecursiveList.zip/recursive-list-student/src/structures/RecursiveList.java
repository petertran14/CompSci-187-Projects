package structures;

import java.util.Iterator;

public class RecursiveList<T> implements ListInterface<T> {
	
	private LLNode<T> head;
	private LLNode<T> tail;
	private int size;

	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return new LinkedNodeIterator<T>(this.head);
	}

	@Override
	public int size() {
		
		return this.size;
	}

	@Override
	public ListInterface<T> insertFirst(T elem) {
		
		// If the parameter is null.
		if (elem == null) {
			
			throw new NullPointerException();
		}
		
		// If the list was originally empty.
		if (this.isEmpty()) {
			
			LLNode<T> node = new LLNode<T>(elem, null);
			this.head = node;
			this.tail = this.head;
		}
		
		// The list has at least one node in it.
		else {
			
			LLNode<T> node = new LLNode<T>(elem, this.head);
			this.head = node;
		}
		
		// Increment size.
		this.size++;
		
		// This returns the modified list, but do we want to return a copy of the modified list?
		return this;
	}

	@Override
	public ListInterface<T> insertLast(T elem) {
		
		// If the elem is null.
		if (elem == null) {
			
			throw new NullPointerException();
		}
		
		// If the list is empty.
		if (this.isEmpty()) {
			
			LLNode<T> node = new LLNode<T>(elem, null);
			this.head = node;
			this.tail = node;
		}
		
		// Since I have a tail pointer, insertLast is O(1).
		else {
			
			this.tail.setNext(new LLNode<T>(elem, null));
			this.tail = this.tail.getNext();
		}
		
		// Increment size.
		this.size++;
		
		return this;
	}

	@Override
	public ListInterface<T> insertAt(int index, T elem) {
		
		// If the elem is null.
		if (elem == null) {
			
			throw new NullPointerException();
		}
		
		// If the index does not represent elements in our list.
		if (index > this.size || index < 0) {
			
			throw new IndexOutOfBoundsException();
		}
		
		// If the index is at 0, this is an edge case.
		if (index == 0) {
			
			this.insertFirst(elem);
			
			return this;
		}
		
		// If the index is at the very end of the list.
		if (index == this.size) {
			
			this.insertLast(elem);
			
			return this;
		}
		
		// The idea is that I want to stop one node before the target node to redirect pointers. And if
		// the target node's index is 0, this will be an edge case that I need to handle outside this recursive call.
		return insertAt(elem, 0, index, this.head);
	}
	
	private ListInterface<T> insertAt(T elem, int currIndex, int insertIndex, LLNode<T> currNode) {
		
		// Stop one node behind the target node to redirect pointers.
		if (currIndex == insertIndex - 1) {
			
			LLNode<T> node = new LLNode<T>(elem, currNode.getNext());
			currNode.setNext(node);
			this.size++;
			
			return this;
		}
		
		// Recursive case that gets closer to the insertIndex.
		return insertAt(elem, ++currIndex, insertIndex, currNode.getNext());
	}

	@Override
	public T removeFirst() {
		
		if (this.isEmpty()) {
			
			throw new IllegalStateException();
		}
		
		// Get the data from the head.
		T data = this.head.getData();
		
		// Edge case where size is 1.
		if (this.size == 1) {
			
			this.head = null;
			this.tail = null;
		}
		
		else {
			
			// Another pointer to break the link.
			LLNode<T> garbage = this.head;
			
			// Move head up one node.
			this.head = this.head.getNext();
			
			// Break the link.
			garbage.setNext(null);
		}
		
		this.size--;
		
		return data;
	}

	@Override
	public T removeLast() {
		
		if (this.isEmpty()) {
			
			throw new IllegalStateException();
		}
		
		return this.removeLast(this.head);
	}
	
	private T removeLast(LLNode<T> currNode) {
		
		// Edge case where the size is 1.
		if (this.size == 1) {
			
			T data = currNode.getData();
			this.head = this.tail = null;
			this.size--;
			
			return data;
		}
		
		// Once we are one node behind the last node, stop.
		if (currNode.getNext().getNext() == null) {
			
			// Get the data of the last node.
			T data = currNode.getNext().getData();
			
			// Disconnect the next pointer of the current node from the last.
			currNode.setNext(null);
			
			// Update tail pointer.
			this.tail = currNode;
			
			// Decrement size.
			this.size--;
			
			// Return our found data.
			return data;
		}
		
		// Gets closer to the end of the list.
		return this.removeLast(currNode.getNext());
	}

	@Override
	public T removeAt(int i) {
		
		// Dependent on size, so it handles empty case as well.
		if (i < 0 || i >= this.size) {
			
			throw new IndexOutOfBoundsException();
		}
		
		return removeAt(i, 0, this.head);
	}
	
	private T removeAt(int targetIndex, int currIndex, LLNode<T> currNode) {
		
		// Edge case where the node is the first index, or where there is only one node in the list.
		if (targetIndex == 0 || this.size == 1) {
			
			return this.removeFirst();
		}
		
		// Edge case where the node is the last index.
		if (targetIndex == this.size - 1) {
			
			return this.removeLast();
		}
		
		// Base case, where we have found the node behind the target node. The node is somewhere in the middle.
		if (currIndex == targetIndex - 1) {
			
			// Get the data from the target node.
			T data = currNode.getNext().getData();
			
			LLNode<T> garbage = currNode.getNext();
			currNode.setNext(currNode.getNext().getNext());
			garbage.setNext(null);
			this.size--;
			
			return data;
		}
		
		return removeAt(targetIndex, ++currIndex, currNode.getNext());
	}

	@Override
	public T getFirst() {
		
		if (this.isEmpty()) {
			
			throw new IllegalStateException();
		}
		
		return this.head.getData();
	}

	@Override
	public T getLast() {
		
		if (this.isEmpty()) {
			
			throw new IllegalStateException();
		}
		
		return this.tail.getData();
	}

	@Override
	public T get(int i) {
		
		if (i < 0 || i >= this.size) {
			
			throw new IndexOutOfBoundsException();
		}
		
		return this.get(i, 0, this.head);
	}
	
	private T get(int targetIndex, int currIndex, LLNode<T> currNode) {
		
		// Found the index. Return the data at index.
		if (currIndex == targetIndex) {
			
			return currNode.getData();
		}
		
		// Traverses the list.
		return this.get(targetIndex, ++currIndex, currNode.getNext());
	}

	@Override
	public boolean remove(T elem) {
		
		return this.remove(elem, this.head, 0);
	}
	
	private boolean remove(T elem, LLNode<T> currNode, int index) {
		
		if (elem == null) {
			
			throw new NullPointerException();
		}
		
		// Base case, if we have reached the end of the list without finding elem, return false.
		if (currNode == null || (index == this.size - 1 && this.size != 1)) {
			
			return false;
		}
		
		// Elem is the first node.
		if (this.head.getData().equals(elem)) {
			
			this.removeFirst();
			return true;
		}
		
		// If we have found the elem somewhere in the middle, do some pointer surgery.
		if (currNode.getNext().getData().equals(elem)) {
			
			LLNode<T> garbage = currNode.getNext();
			currNode.setNext(currNode.getNext().getNext());
			garbage.setNext(null);
			this.size--;
			
			return true;
		}
		
		return this.remove(elem, currNode.getNext(), ++index);
	}

	@Override
	public int indexOf(T elem) {
		
		return this.indexOf(elem, 0, this.head);
	}
	
	private int indexOf(T elem, int currIndex, LLNode<T> currNode) {
		
		// Base case: if we reach the end of the list and haven't found the elem.
		if (currNode == null) {
			
			return -1;
		}
		
		// Base case: if the current node's data is the elem we are searching for, then return the element's position.
		if (currNode.getData().equals(elem)) {
			
			return currIndex;
		}
		
		// Recursive case: keep traversing the list until we find what we are looking for.
		// A post increment operator will not evaluate until the after the method call, but a pre-increment operator
		// will evaluate inside the parameter.
		return this.indexOf(elem, ++currIndex, currNode.getNext());
	}

	@Override
	public boolean isEmpty() {
		
		return this.head == null;
	}

}
