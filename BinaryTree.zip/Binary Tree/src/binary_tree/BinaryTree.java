package binary_tree;

import node.Node;

public class BinaryTree {

	// Root node
	private Node root;
	
	// Constructor
	public BinaryTree(int key) {
		
		// Sets the root node to hold the specified value
		this.root = new Node(key);
	}
	
	public void add(Node node, int value) {
		
		if (node == null) {
			
			node = new Node(value);
		}
		
		else if (value <= node.getValue()) {
			
			root.left = add(node.getLeft(), value);
		}
	}
}
