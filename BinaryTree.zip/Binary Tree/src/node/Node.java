package node;

public class Node {

	public int data;
	public Node left;
	public Node right;
	
	public Node(int data) {
		
		this.data = data;
		this.left = null;
		this.right = null;
	}
	
	public int getValue() {
		
		return this.data;
	}
	
	public Node getLeft() {
		
		return this.left;
	}
	
	public Node getRight() {
		
		return this.right;
	}
}
