package guessme;

/**
 * An Array-based implementation of the Guess-A-Number game
 */
public class ArrayGame {
	
	private final int POSSIBLE_GUESSES = 9000;
	private final int INITIAL_GUESS = 1000;

	// stores the next number to guess
	private int guess;
	
	// TODO: declare additional data members, such as arrays that store
	// prior guesses, eliminated candidates etc.
	
	// Stores an array of int to represent prior guesses.
	private int[] priorGuesses;
	
	// Stores an array of eliminated numbers.
	//private int[] eliminatedNumbers;
	
	// Stores a flag for each guess, indicating if it is eliminated or not. True = eliminated. False = still in the game.
	private boolean[] flagGuesses;
	
	// Game is over
	private boolean gameOver;

	// NOTE: only primitive type arrays are allowed, such as int[], boolean[] etc.
	// You MAY NOT use any Collection type (such as ArrayList) provided by Java.
	
	/********************************************************
	 * NOTE: you are allowed to add new methods if necessary,
	 * but DO NOT remove any provided method, otherwise your
	 * code will fail the JUnit tests!
	 * Also DO NOT create any new Java files, as they will
	 * be ignored by the autograder!
	 *******************************************************/
	
	// ArrayGame constructor method
	public ArrayGame() {
		
		this.guess = INITIAL_GUESS;
		this.priorGuesses = null;
		this.flagGuesses = new boolean[POSSIBLE_GUESSES];
		//this.eliminatedNumbers = null;
		this.gameOver = false;
	}
	
	// Resets data members and game state so we can play again
	public void reset() {
		
		// Reset initial guess.
		this.guess = INITIAL_GUESS;
		
		// Reset the array.
		this.priorGuesses = null;
		//this.eliminatedNumbers = null;
		this.gameOver = false;
		
		// All boolean values in the array are initially false.
		for (int i = 0; i < POSSIBLE_GUESSES; i++) {
			
			this.flagGuesses[i] = false;
		}
	}
	
	// Returns true if n is a prior guess; false otherwise.
	public boolean isPriorGuess(int n) {
		
		// If the array is empty, then there is no matching int with n.
		if (this.priorGuesses == null) {
			
			return false;
		}
		
		// Loop through the prior guess array. Not all of it may be filled, so we only need to loop
		// through up to the number of guesses we have made so far.
		for (int i = 0; i < this.priorGuesses.length; i++) {
			
			// Return true is there is a match.
			if (this.priorGuesses[i] == n) {
				
				return true;
			}
		}
		
		return false;	
	}
	
	// Returns the number of guesses so far.
	public int numGuesses() {
		
		// If the array is empty.
		if (this.priorGuesses == null) {
			
			return 0;
		}
		
		return this.priorGuesses.length;
	}
	
	/**
	 * Returns the number of matches between integers a and b.
	 * You can assume that both are 4-digits long (i.e. between 1000 and 9999).
	 * The return value must be between 0 and 4.
	 * 
	 * A match is the same digit at the same location. For example:
	 *   1234 and 4321 have 0 match;
	 *   1234 and 1114 have 2 matches (1 and 4);
	 *   1000 and 9000 have 3 matches (three 0's).
	 */
	public static int numMatches(int a, int b) { // DO NOT remove the static qualifier
		
		// Keeps track of the number of matches.
		int matches = 0;
		
		while (a != 0) {
			
			// If the digits match, increment.
			if ((a % 10) == (b % 10)) {
				
				matches++;
			}
			
			// Shrink down the number.
			a = a / 10;
			b = b / 10;
		}
		
		return matches;
	}
	
	/**
	 * Returns true if the game is over; false otherwise.
	 * The game is over if the number has been correctly guessed
	 * or if all candidates have been eliminated.
	 */
	public boolean isOver() {
		
		if (this.gameOver) {
			
			return true;
		}
		
		return false;
	}
	
	/**
	 * Adds eliminated numbers to the array that holds them.
	 * 
	 * @param num
	 */
//	public void addToEliminated(int num) {
//		
//		if (this.eliminatedNumbers == null) {
//			
//			this.eliminatedNumbers = new int[1];
//		}
//		
//		// If the array had stuff already in it.
//		else {
//			
//			// Copy over the integers to a new array that has space for 1 extra integer.
//			int[] copy = new int[this.eliminatedNumbers.length + 1];
//			
//			for (int i = 0; i < this.eliminatedNumbers.length; i++) {
//				
//				copy[i] = this.eliminatedNumbers[i];
//			}
//			
//			this.eliminatedNumbers = copy;
//		}
//		
//		this.eliminatedNumbers[this.eliminatedNumbers.length - 1] = num;
//	}
	
	/**
	 * Return the size of the eliminated array.
	 * 
	 * @return int
	 */
//	public int getEliminatedSize() {
//		
//		return this.eliminatedNumbers.length;
//	}
	
	/**
	 * Returns true or false, whether or not the number of interest has been eliminated.
	 * 
	 * @param num
	 * @return boolean
	 */
//	public boolean isEliminated(int num) {
//		
//		if (this.eliminatedNumbers == null) {
//			
//			return false;
//		}
//		
//		for (int i = 0; i < this.eliminatedNumbers.length; i++) {
//			
//			if (this.eliminatedNumbers[i] == num) {
//				
//				return true;
//			}
//		}
//		
//		return false;
//	}
	
	/**
	 * Adds previous guesses to the array that holds them. 
	 * 
	 * @param guess
	 */
	public void addToPriorGuess(int guess) {
		
		// If the array was initially empty
		if (this.priorGuesses == null) {
			
			// Allocate memory to hold 1 integer.
			this.priorGuesses = new int[1];
			this.priorGuesses[this.priorGuesses.length - 1] = guess;
		}
		
		// If the array had stuff already in it. No duplicates.
		else {
			
			// Copy over the integers to a new array that has space for 1 extra integer.
			int[] copy = new int[this.priorGuesses.length + 1];
			
			for (int i = 0; i < this.priorGuesses.length; i++) {
				
				copy[i] = this.priorGuesses[i];
			}
			
			this.priorGuesses = copy;
			
			this.priorGuesses[this.priorGuesses.length - 1] = guess;
		}
	}
	
	// Returns the guess number and adds it to the list of prior guesses.
	// Since any of them is equally likely to be the groundtruth, the algorithm simply chooses the first candidate, 1000, 
	// as the initial guess. Therefore the getGuess() method will initially return 1000 as the first guess.

	public int getGuess() {
		// TODO: add guess to the list of prior guesses.
		
		// If we don't call updateGuess, then our first guess is 1000 since I initialized it in the constructor.
		this.addToPriorGuess(this.guess);
		return this.guess;
	}
	
	/**
	 * Updates guess based on the number of matches of the previous guess.
	 * If nmatches is 4, the previous guess is correct and the game is over.
	 * Check project description for implementation details.
	 * 
	 * Returns true if the update has no error; false if all candidates
	 * have been eliminated (indicating a state of error);
	 */
	public boolean updateGuess(int nmatches) {
		
		// If the host indicates we have found the number. Then the game is over.
		if (nmatches == 4) {
			
			this.gameOver = true;
			return true;
		}
		
		// Cycle through 1000 - 9000.
		for (int i = 0; i < POSSIBLE_GUESSES; i++) {
			
			// Skip already eliminated numbers.
			if (!this.flagGuesses[i]) {
				
				// Get number of matches.
				int matches = ArrayGame.numMatches(this.guess, i + 1000);
				
				// Eliminate numbers that have different matches.
				if (nmatches != matches) {
					//System.out.println(this.guess);
					this.flagGuesses[i] = true;
					//this.addToEliminated(i + 1000);
				}
			}
		}
		
		// State of Error.
		if (this.allEliminated()) {
			
			this.gameOver = true;
			return false;
		}
		
		// Else, update guess.
		this.guess = this.getFirstCandidate();
		
		return true;
	}
	
	/**
	 * Returns the first number that has not been eliminated.
	 * 
	 * @return int
	 */
	public int getFirstCandidate() {
		
		for (int i = 0; i < POSSIBLE_GUESSES; i++) {
			
			if (!this.flagGuesses[i]) {
				//System.out.println(this.guess);
				return (i + 1000);
			}
		}
		
		return -1;
	}
	
	/**
	 * Returns true or false, whether or not all the candidates have been eliminated.
	 * 
	 * @return boolean
	 */
	public boolean allEliminated() {
		
		for (int i = 0; i < this.POSSIBLE_GUESSES; i++) {
			
			if (!this.flagGuesses[i]) {
				
				return false;
			}
		}
		
		// The list is partially filled, which means we still have some candidates left on the playing field.
		return true;
	}
	
	// Returns the list of guesses so far as an integer array.
	// The size of the array must be the number of prior guesses.
		// Arrays are immutable after they have been initialized. I can try to add one at a time.
	
	// Returns null if there has been no prior guess
	public int[] priorGuesses() {
		
		// If there was no prior guesses.
		if (this.priorGuesses == null) {
			
			return null;
		}
		
		// Otherwise, copy over the array to a copy and return it.
		int[] list = new int[this.priorGuesses.length];
		
		for (int i = 0; i < this.priorGuesses.length; i++) {
			
			list[i] = this.priorGuesses[i];
		}
		
		return list;
	}
	
	public void displayCandidateNumbers() {
		
		for (int i = 0; i < 9000; i++) {
			
			if (!this.flagGuesses[i]) {
				
				System.out.println(i + 1000);
			}
		}
	}
}
