package guessme;

public class Driver {

	public static void main(String[] args) {
		
//		int[] array = new int[4];
//		
//		for (int i = 0; i < 4; i++) {
//			
//			array[i] = i;
//		}
//		
////		for (int item : array) {
////			
////			System.out.println(item);
////		}
//		
//		int[] copy = new int[2];
//		
//		array = copy;
//		
//		for (int item : array) {
//			
//			System.out.println(item);
//		}
		
		for (int i = 0; i < 9000; i++) {
			
			System.out.println(i + 1000);
		}
	}
}
