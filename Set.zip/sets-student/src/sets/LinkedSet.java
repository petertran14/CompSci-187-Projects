package sets;

import java.util.Iterator;

/**
 * A LinkedList-based implementation of Set
 */

  /********************************************************
   * NOTE: Before you start, check the Set interface in
   * Set.java for detailed description of each method.
   *******************************************************/
  
  /********************************************************
   * NOTE: for this project you must use linked lists
   * implemented by yourself. You are NOT ALLOWED to use
   * Java arrays of any type, or any Collection-based class 
   * such as ArrayList, Vector etc. You will receive a 0
   * if you use any of them.
   *******************************************************/ 

  /********************************************************
   * NOTE: you are allowed to add new methods if necessary,
   * but do NOT add new files (as they will be ignored).
   *******************************************************/

public class LinkedSet<E> implements Set<E> {
  private LinkedNode<E> head = null;

  // Constructors
  public LinkedSet() {
  }

  public LinkedSet(E e) {
    this.head = new LinkedNode<E>(e, null);
  }

  private LinkedSet(LinkedNode<E> head) {
    this.head = head;
  }

  @Override
  public int size() {
    
	  // The linked list is empty if head == null.
	  if (this.head == null) {
		  
		  return 0;
	  }
   
	  LinkedNode<E> temp = this.head;
	  int size = 0;
	  
	  // Otherwise, traverse the list and keep a count of the number of nodes.
	  while (temp != null) {
		  
		  temp = temp.getNext();
		  size++;
	  }
	  
	  return size;
  }

  @Override
  public boolean isEmpty() {
    
	  return this.head == null;
  }

  @Override
  public Iterator<E> iterator() {
    return new LinkedNodeIterator<E>(this.head);
  }

  /**
   * I am testing the E data within the LinkedNode class. If they are the same, I am assuming they are
   * equal nodes.
   */
  @Override
  public boolean contains(Object o) {
    
	  // If the list is empty, there can be no matching objects.
	  if (this.isEmpty()) {
		  
		  return false;
	  }
	  
	  LinkedNode<E> temp = this.head;
	  
	  // Traverse the list. 
	  while (temp != null) {
		  
		  // If the object o matches data in the node, return true.
		  if (temp.getData().equals(o)) {
			  
			  return true;
		  }
		  
		  temp = temp.getNext();
	  }
	  
	  return false;
  } 
  
  /**
   * Set<E> that, is an object of the set class. It inherits all the member methods. But does it have nodes?
   * Set<E> that is not a node, but a data structure that has objects of type E.
   */
  
  @Override
  public boolean isSubset(Set<E> that) {
	  
	  if (this.size() > that.size()) {
		  
		  return false;
	  }
    
	  for (E item : this) {
		  
		  if (!that.contains(item)) {
			  
			  return false;
		  }
	  }
	  
	  return true;
  }

  @Override
  public boolean isSuperset(Set<E> that) {
    
	  if (this.size() < that.size()) {
		  
		  return false;
	  }
	  
	  for (E item : that) {
		  
		  if (!this.contains(item)) {
			  
			  return false;
		  }
	  }
	  
	  return true;
  }

  /**
   * What is e? Is it "data? Or is it a whole new node?
   * It is data. 
   */
  @Override
  public Set<E> adjoin(E e) {
	  
	  LinkedNode<E> copy = new LinkedNode<>(e, this.head);
	  Set<E> set = new LinkedSet<E>();
	  
	  if (this.contains(e)) {
		  
		  return new LinkedSet<E>(this.head);
	  }
    
	  // If the element e is not in our list. Does not allow duplicates.
	  else {
		  
		  // Immuteability means this.head cannot be assigned.
		  set = new LinkedSet<E>(copy);
	  }
	  
	// Return a copy of our list.
	  return set;
  }

  @Override
  public Set<E> union(Set<E> that) {
    
	  Set<E> set = new LinkedSet<E>(this.head);
	  
	  for (E item : that) {
		  
		  set = set.adjoin(item);
	  }
	  
	  return set;
  }

  @Override
  public Set<E> intersect(Set<E> that) {
   
	  Set<E> set = new LinkedSet<E>();
	  
	  for (E item : that) {
		  
		  if (this.contains(item)) {
			  
			  set = set.adjoin(item);
		  }
	  }
	  
	  return set;
  }

  @Override
  public Set<E> subtract(Set<E> that) {
	  
	  if (this.equals(that)) {
		  
		  return new LinkedSet<E>();
	  }
	  
	  Set<E> set = new LinkedSet<E>(this.head);
	  
	  for (E item : that) {
		  
		  if (this.contains(item)) {
			  
			  set = set.remove(item);
		  }
	  }
	  
	  return set;
  }

  @Override
  public Set<E> remove(E e) {
    
	  // If e does not exist in our list.
	  if (!this.contains(e)) {
		  
		  return new LinkedSet<E>(this.head);
	  }
	  
	  // If our list is empty.
	  if (this.isEmpty()) {
		  
		  return new LinkedSet<E>();
	  }
	  
	  Set<E> list = new LinkedSet<E>();
	  LinkedNode<E> temp = this.head;
	  
	  while (temp != null) {
		  
		  if (!temp.getData().equals(e)) {
			  
			  list = list.adjoin(temp.getData());
		  }
		  
		  temp = temp.getNext();
	  }
	  
	  return list;
  }
  
  

  @Override
  @SuppressWarnings("unchecked")
  public boolean equals(Object o) {
    if (! (o instanceof Set)) {
      return false;
    }
    Set<E> that = (Set<E>)o;
    return this.isSubset(that) && that.isSubset(this);
  }

  @Override
    public int hashCode() {
    int result = 0;
    for (E e : this) {
      result += e.hashCode();
    }
    return result;
  }
  
  
}
