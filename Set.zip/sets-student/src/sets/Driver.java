package sets;

public class Driver {

	public static void main(String[] args) {
		
		Integer[] array = new Integer[0];
		int size = 0;
		
		for (Integer item : array) {
			
			size++;
		}
		
		System.out.println(size);
	}
}
